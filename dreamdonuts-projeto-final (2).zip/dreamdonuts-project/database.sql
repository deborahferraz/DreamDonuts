-- Script de criação do banco de dados DreamDonuts
-- Baseado no DER fornecido

-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS dreamdonuts_db;
USE dreamdonuts_db;

-- Tabela Endereco
CREATE TABLE Endereco (
    idEndereco INT PRIMARY KEY AUTO_INCREMENT,
    logradouro VARCHAR(100) NOT NULL,
    numero VARCHAR(10) NOT NULL,
    referencia VARCHAR(45),
    cep VARCHAR(9) NOT NULL,
    CidadeIdCidade INT NOT NULL
);

-- Tabela Cidade (referenciada por Endereco)
CREATE TABLE Cidade (
    idCidade INT PRIMARY KEY AUTO_INCREMENT,
    nomeCidade VARCHAR(100) NOT NULL
);

-- Tabela Pessoa
CREATE TABLE Pessoa (
    CpfPessoa VARCHAR(20) PRIMARY KEY,
    nomePessoa VARCHAR(60) NOT NULL,
    dataNascimentoPessoa DATE,
    EnderecoIdEndereco INT,
    FOREIGN KEY (EnderecoIdEndereco) REFERENCES Endereco(idEndereco)
);

-- Tabela Cliente
CREATE TABLE Cliente (
    PessoaCpfPessoa VARCHAR(20) PRIMARY KEY,
    rendaCliente DOUBLE,
    dataDeCadastroCliente DATE,
    FOREIGN KEY (PessoaCpfPessoa) REFERENCES Pessoa(CpfPessoa)
);

-- Tabela Cargo
CREATE TABLE Cargo (
    idCargo INT PRIMARY KEY AUTO_INCREMENT,
    nomeCargo VARCHAR(45) NOT NULL
);

-- Tabela Funcionario
CREATE TABLE Funcionario (
    PessoaCpfPessoa VARCHAR(20) PRIMARY KEY,
    salario DOUBLE,
    CargoIdCargo INT,
    porcentagemComissao DOUBLE,
    FOREIGN KEY (PessoaCpfPessoa) REFERENCES Pessoa(CpfPessoa),
    FOREIGN KEY (CargoIdCargo) REFERENCES Cargo(idCargo)
);

-- Tabela Produto
CREATE TABLE Produto (
    idProduto INT PRIMARY KEY AUTO_INCREMENT,
    nomeProduto VARCHAR(45) NOT NULL,
    quantidadeEmEstoque INT,
    precoUnitario DOUBLE NOT NULL
);

-- Tabela Pedido
CREATE TABLE Pedido (
    idPedido INT PRIMARY KEY AUTO_INCREMENT,
    dataDoPedido DATE NOT NULL,
    ClientePessoaCpfPessoa VARCHAR(20),
    FuncionarioPessoaCpfPessoa VARCHAR(20),
    FOREIGN KEY (ClientePessoaCpfPessoa) REFERENCES Cliente(PessoaCpfPessoa),
    FOREIGN KEY (FuncionarioPessoaCpfPessoa) REFERENCES Funcionario(PessoaCpfPessoa)
);

-- Tabela PedidoHasProduto (relacionamento N:M entre Pedido e Produto)
CREATE TABLE PedidoHasProduto (
    ProdutoIdProduto INT,
    PedidoIdPedido INT,
    quantidade INT NOT NULL,
    precoUnitario DOUBLE NOT NULL,
    PRIMARY KEY (ProdutoIdProduto, PedidoIdPedido),
    FOREIGN KEY (ProdutoIdProduto) REFERENCES Produto(idProduto),
    FOREIGN KEY (PedidoIdPedido) REFERENCES Pedido(idPedido)
);

-- Tabela FormaDePagamento
CREATE TABLE FormaDePagamento (
    idFormaPagamento INT PRIMARY KEY AUTO_INCREMENT,
    nomeFormaPagamento VARCHAR(100) NOT NULL
);

-- Tabela Pagamento
CREATE TABLE Pagamento (
    PedidoIdPedido INT PRIMARY KEY,
    dataPagamento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valorTotalPagamento DOUBLE NOT NULL,
    FOREIGN KEY (PedidoIdPedido) REFERENCES Pedido(idPedido)
);

-- Tabela PagamentoHasFormaPagamento (relacionamento N:M entre Pagamento e FormaDePagamento)
CREATE TABLE PagamentoHasFormaPagamento (
    PagamentoIdPedido INT,
    FormaPagamentoIdFormaPagamento INT,
    valorPago DOUBLE NOT NULL,
    PRIMARY KEY (PagamentoIdPedido, FormaPagamentoIdFormaPagamento),
    FOREIGN KEY (PagamentoIdPedido) REFERENCES Pagamento(PedidoIdPedido),
    FOREIGN KEY (FormaPagamentoIdFormaPagamento) REFERENCES FormaDePagamento(idFormaPagamento)
);

-- Adicionando a constraint de chave estrangeira para Endereco -> Cidade
ALTER TABLE Endereco ADD FOREIGN KEY (CidadeIdCidade) REFERENCES Cidade(idCidade);

-- Inserção de dados iniciais

-- Cidades
INSERT INTO Cidade (nomeCidade) VALUES 
('São Paulo'),
('Rio de Janeiro'),
('Belo Horizonte'),
('Curitiba'),
('Porto Alegre');

-- Endereços
INSERT INTO Endereco (logradouro, numero, referencia, cep, CidadeIdCidade) VALUES 
('Rua das Flores', '123', 'Próximo ao shopping', '01234-567', 1),
('Avenida Paulista', '456', 'Em frente ao metrô', '01310-100', 1),
('Rua da Praia', '789', 'Perto da praia', '22070-900', 2),
('Rua XV de Novembro', '321', 'Centro histórico', '80020-310', 4);

-- Pessoas
INSERT INTO Pessoa (CpfPessoa, nomePessoa, dataNascimentoPessoa, EnderecoIdEndereco) VALUES 
('123.456.789-01', 'João Silva', '1990-05-15', 1),
('987.654.321-02', 'Maria Santos', '1985-08-22', 2),
('456.789.123-03', 'Pedro Oliveira', '1992-12-10', 3),
('789.123.456-04', 'Ana Costa', '1988-03-18', 4),
('321.654.987-05', 'Carlos Ferreira', '1995-07-25', 1);

-- Clientes
INSERT INTO Cliente (PessoaCpfPessoa, rendaCliente, dataDeCadastroCliente) VALUES 
('123.456.789-01', 3500.00, '2024-01-15'),
('987.654.321-02', 4200.00, '2024-02-20'),
('456.789.123-03', 2800.00, '2024-03-10');

-- Cargos
INSERT INTO Cargo (nomeCargo) VALUES 
('Vendedor'),
('Gerente'),
('Caixa'),
('Confeiteiro');

-- Funcionários
INSERT INTO Funcionario (PessoaCpfPessoa, salario, CargoIdCargo, porcentagemComissao) VALUES 
('789.123.456-04', 2500.00, 1, 5.0),
('321.654.987-05', 4500.00, 2, 10.0);

-- Produtos (Donuts)
INSERT INTO Produto (nomeProduto, quantidadeEmEstoque, precoUnitario) VALUES 
('Donut Arco-íris', 50, 6.23),
('Donut Chocolate Especial', 30, 7.43),
('Donut Glacê Rosa', 40, 6.32),
('Donut Morango', 25, 5.90),
('Donut Baunilha', 35, 5.50),
('Donut Caramelo', 20, 6.80),
('Donut Coco', 45, 5.75);

-- Formas de Pagamento
INSERT INTO FormaDePagamento (nomeFormaPagamento) VALUES 
('Dinheiro'),
('Cartão de Crédito'),
('Cartão de Débito'),
('PIX'),
('Vale Alimentação');

-- Pedidos de exemplo
INSERT INTO Pedido (dataDoPedido, ClientePessoaCpfPessoa, FuncionarioPessoaCpfPessoa) VALUES 
('2024-09-01', '123.456.789-01', '789.123.456-04'),
('2024-09-02', '987.654.321-02', '789.123.456-04'),
('2024-09-03', '456.789.123-03', '321.654.987-05');

-- Itens dos pedidos
INSERT INTO PedidoHasProduto (ProdutoIdProduto, PedidoIdPedido, quantidade, precoUnitario) VALUES 
(1, 1, 2, 6.23),
(2, 1, 1, 7.43),
(3, 2, 3, 6.32),
(1, 3, 1, 6.23),
(4, 3, 2, 5.90);

-- Pagamentos
INSERT INTO Pagamento (PedidoIdPedido, valorTotalPagamento) VALUES 
(1, 19.89),
(2, 18.96),
(3, 18.03);

-- Formas de pagamento utilizadas
INSERT INTO PagamentoHasFormaPagamento (PagamentoIdPedido, FormaPagamentoIdFormaPagamento, valorPago) VALUES 
(1, 2, 19.89),
(2, 4, 18.96),
(3, 1, 18.03);

