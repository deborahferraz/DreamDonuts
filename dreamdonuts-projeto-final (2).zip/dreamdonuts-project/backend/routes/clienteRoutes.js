const express = require('express');
const router = express.Router();
const clienteController = require('../controllers/clienteController');

// Listar todos os clientes
router.get('/', clienteController.listarClientes);

// Obter cliente por CPF
router.get('/:cpf', clienteController.obterCliente);

// Criar novo cliente
router.post('/', clienteController.criarCliente);

// Atualizar cliente
router.put('/:cpf', clienteController.atualizarCliente);

// Deletar cliente
router.delete('/:cpf', clienteController.deletarCliente);

// Listar cidades para dropdown
router.get('/dados/cidades', clienteController.listarCidades);

module.exports = router;

