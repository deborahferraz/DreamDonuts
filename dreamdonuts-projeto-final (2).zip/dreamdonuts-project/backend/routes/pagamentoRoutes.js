const express = require('express');
const router = express.Router();
const pagamentoController = require('../controllers/pagamentoController');

// Listar todos os pagamentos
router.get('/', pagamentoController.listarPagamentos);

// Obter pagamento por ID do pedido
router.get('/:pedidoId', pagamentoController.obterPagamento);

// Criar novo pagamento
router.post('/', pagamentoController.criarPagamento);

// Atualizar pagamento
router.put('/:pedidoId', pagamentoController.atualizarPagamento);

// Deletar pagamento
router.delete('/:pedidoId', pagamentoController.deletarPagamento);

// Listar formas de pagamento para dropdown
router.get('/dados/formas-pagamento', pagamentoController.listarFormasPagamento);

// Listar pedidos sem pagamento para dropdown
router.get('/dados/pedidos-sem-pagamento', pagamentoController.listarPedidosSemPagamento);

module.exports = router;

