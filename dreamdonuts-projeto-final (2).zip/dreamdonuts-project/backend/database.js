const { Pool } = require('pg');

// Configuração da conexão com PostgreSQL
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'dreamdonuts_db',
    password: 'postgres',
    port: 5432,
});

// Função para executar queries
async function query(text, params) {
    const start = Date.now();
    try {
        const res = await pool.query(text, params);
        const duration = Date.now() - start;
        console.log('Executed query', { text, duration, rows: res.rowCount });
        return res;
    } catch (error) {
        console.error('Database query error:', error);
        throw error;
    }
}

// Função para obter um cliente do pool
async function getClient() {
    return pool.connect();
}

module.exports = {
    query,
    getClient,
    pool
};

