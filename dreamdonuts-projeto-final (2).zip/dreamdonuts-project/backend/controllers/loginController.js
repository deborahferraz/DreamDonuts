const db = require('../database');

// Função para fazer login
async function login(req, res) {
    try {
        const { email, senha } = req.body;
        
        if (!email || !senha) {
            return res.status(400).json({ error: 'Email e senha são obrigatórios' });
        }

        // Buscar funcionário por email (usando CPF como email para simplificar)
        const result = await db.query(
            `SELECT f.PessoaCpfPessoa, p.nomePessoa, c.nomeCargo 
             FROM Funcionario f 
             JOIN Pessoa p ON f.PessoaCpfPessoa = p.CpfPessoa 
             JOIN Cargo c ON f.CargoIdCargo = c.idCargo 
             WHERE p.CpfPessoa = $1`,
            [email]
        );

        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'Credenciais inválidas' });
        }

        const funcionario = result.rows[0];
        
        // Para simplificar, vamos aceitar qualquer senha para demonstração
        // Em um sistema real, você verificaria a senha hash
        
        // Criar cookie de sessão
        res.cookie('userSession', {
            cpf: funcionario.pessoacpfpessoa,
            nome: funcionario.nomepessoa,
            cargo: funcionario.nomecargo
        }, {
            httpOnly: true,
            maxAge: 24 * 60 * 60 * 1000 // 24 horas
        });

        res.json({
            success: true,
            user: {
                cpf: funcionario.pessoacpfpessoa,
                nome: funcionario.nomepessoa,
                cargo: funcionario.nomecargo
            }
        });

    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Função para fazer logout
async function logout(req, res) {
    try {
        res.clearCookie('userSession');
        res.json({ success: true, message: 'Logout realizado com sucesso' });
    } catch (error) {
        console.error('Erro no logout:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Função para verificar se o usuário está logado
async function verificarLogin(req, res) {
    try {
        const userSession = req.cookies.userSession;
        
        if (!userSession) {
            return res.status(401).json({ error: 'Usuário não logado' });
        }

        res.json({
            success: true,
            user: userSession
        });

    } catch (error) {
        console.error('Erro na verificação de login:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    login,
    logout,
    verificarLogin
};

