const db = require('../database');

// Listar todos os clientes com informações da pessoa
async function listarClientes(req, res) {
    try {
        const result = await db.query(`
            SELECT 
                c.PessoaCpfPessoa,
                p.nomePessoa,
                p.dataNascimentoPessoa,
                c.rendaCliente,
                c.dataDeCadastroCliente,
                e.logradouro,
                e.numero,
                e.cep,
                ci.nomeCidade
            FROM Cliente c
            JOIN Pessoa p ON c.PessoaCpfPessoa = p.CpfPessoa
            LEFT JOIN Endereco e ON p.EnderecoIdEndereco = e.idEndereco
            LEFT JOIN Cidade ci ON e.CidadeIdCidade = ci.idCidade
            ORDER BY p.nomePessoa
        `);

        res.json({
            success: true,
            clientes: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar clientes:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Obter cliente por CPF
async function obterCliente(req, res) {
    try {
        const { cpf } = req.params;
        const result = await db.query(`
            SELECT 
                c.PessoaCpfPessoa,
                p.nomePessoa,
                p.dataNascimentoPessoa,
                c.rendaCliente,
                c.dataDeCadastroCliente,
                p.EnderecoIdEndereco,
                e.logradouro,
                e.numero,
                e.referencia,
                e.cep,
                e.CidadeIdCidade,
                ci.nomeCidade
            FROM Cliente c
            JOIN Pessoa p ON c.PessoaCpfPessoa = p.CpfPessoa
            LEFT JOIN Endereco e ON p.EnderecoIdEndereco = e.idEndereco
            LEFT JOIN Cidade ci ON e.CidadeIdCidade = ci.idCidade
            WHERE c.PessoaCpfPessoa = $1
        `, [cpf]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }

        res.json({
            success: true,
            cliente: result.rows[0]
        });
    } catch (error) {
        console.error('Erro ao obter cliente:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Criar novo cliente
async function criarCliente(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { 
            cpf, 
            nome, 
            dataNascimento, 
            renda, 
            endereco 
        } = req.body;
        
        if (!cpf || !nome) {
            return res.status(400).json({ error: 'CPF e nome são obrigatórios' });
        }

        let enderecoId = null;

        // Criar endereço se fornecido
        if (endereco && endereco.logradouro) {
            const enderecoResult = await client.query(
                'INSERT INTO Endereco (logradouro, numero, referencia, cep, CidadeIdCidade) VALUES ($1, $2, $3, $4, $5) RETURNING idEndereco',
                [endereco.logradouro, endereco.numero, endereco.referencia, endereco.cep, endereco.cidadeId]
            );
            enderecoId = enderecoResult.rows[0].idendereco;
        }

        // Criar pessoa
        await client.query(
            'INSERT INTO Pessoa (CpfPessoa, nomePessoa, dataNascimentoPessoa, EnderecoIdEndereco) VALUES ($1, $2, $3, $4)',
            [cpf, nome, dataNascimento || null, enderecoId]
        );

        // Criar cliente
        const clienteResult = await client.query(
            'INSERT INTO Cliente (PessoaCpfPessoa, rendaCliente, dataDeCadastroCliente) VALUES ($1, $2, CURRENT_DATE) RETURNING *',
            [cpf, renda || null]
        );

        await client.query('COMMIT');

        res.status(201).json({
            success: true,
            cliente: clienteResult.rows[0],
            message: 'Cliente criado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao criar cliente:', error);
        
        if (error.code === '23505') { // Violação de chave única
            res.status(400).json({ error: 'CPF já cadastrado' });
        } else {
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    } finally {
        client.release();
    }
}

// Atualizar cliente
async function atualizarCliente(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { cpf } = req.params;
        const { 
            nome, 
            dataNascimento, 
            renda, 
            endereco 
        } = req.body;
        
        if (!nome) {
            return res.status(400).json({ error: 'Nome é obrigatório' });
        }

        // Verificar se cliente existe
        const clienteCheck = await client.query(
            'SELECT * FROM Cliente WHERE PessoaCpfPessoa = $1',
            [cpf]
        );

        if (clienteCheck.rows.length === 0) {
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }

        // Atualizar endereço se fornecido
        if (endereco && endereco.logradouro) {
            const pessoaResult = await client.query(
                'SELECT EnderecoIdEndereco FROM Pessoa WHERE CpfPessoa = $1',
                [cpf]
            );

            const enderecoIdAtual = pessoaResult.rows[0].enderecoidendereco;

            if (enderecoIdAtual) {
                // Atualizar endereço existente
                await client.query(
                    'UPDATE Endereco SET logradouro = $1, numero = $2, referencia = $3, cep = $4, CidadeIdCidade = $5 WHERE idEndereco = $6',
                    [endereco.logradouro, endereco.numero, endereco.referencia, endereco.cep, endereco.cidadeId, enderecoIdAtual]
                );
            } else {
                // Criar novo endereço
                const enderecoResult = await client.query(
                    'INSERT INTO Endereco (logradouro, numero, referencia, cep, CidadeIdCidade) VALUES ($1, $2, $3, $4, $5) RETURNING idEndereco',
                    [endereco.logradouro, endereco.numero, endereco.referencia, endereco.cep, endereco.cidadeId]
                );
                
                // Atualizar pessoa com novo endereço
                await client.query(
                    'UPDATE Pessoa SET EnderecoIdEndereco = $1 WHERE CpfPessoa = $2',
                    [enderecoResult.rows[0].idendereco, cpf]
                );
            }
        }

        // Atualizar pessoa
        await client.query(
            'UPDATE Pessoa SET nomePessoa = $1, dataNascimentoPessoa = $2 WHERE CpfPessoa = $3',
            [nome, dataNascimento || null, cpf]
        );

        // Atualizar cliente
        const result = await client.query(
            'UPDATE Cliente SET rendaCliente = $1 WHERE PessoaCpfPessoa = $2 RETURNING *',
            [renda || null, cpf]
        );

        await client.query('COMMIT');

        res.json({
            success: true,
            cliente: result.rows[0],
            message: 'Cliente atualizado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao atualizar cliente:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Deletar cliente
async function deletarCliente(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { cpf } = req.params;
        
        // Verificar se cliente tem pedidos
        const pedidoCheck = await client.query(
            'SELECT COUNT(*) FROM Pedido WHERE ClientePessoaCpfPessoa = $1',
            [cpf]
        );

        if (parseInt(pedidoCheck.rows[0].count) > 0) {
            return res.status(400).json({ 
                error: 'Não é possível deletar cliente que possui pedidos associados' 
            });
        }

        // Obter endereço antes de deletar
        const pessoaResult = await client.query(
            'SELECT EnderecoIdEndereco FROM Pessoa WHERE CpfPessoa = $1',
            [cpf]
        );

        // Deletar cliente
        const clienteResult = await client.query(
            'DELETE FROM Cliente WHERE PessoaCpfPessoa = $1 RETURNING *',
            [cpf]
        );

        if (clienteResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }

        // Deletar pessoa
        await client.query('DELETE FROM Pessoa WHERE CpfPessoa = $1', [cpf]);

        // Deletar endereço se existir
        const enderecoId = pessoaResult.rows[0].enderecoidendereco;
        if (enderecoId) {
            await client.query('DELETE FROM Endereco WHERE idEndereco = $1', [enderecoId]);
        }

        await client.query('COMMIT');

        res.json({
            success: true,
            message: 'Cliente deletado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao deletar cliente:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Listar cidades para dropdown
async function listarCidades(req, res) {
    try {
        const result = await db.query('SELECT * FROM Cidade ORDER BY nomeCidade');
        res.json({
            success: true,
            cidades: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar cidades:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    listarClientes,
    obterCliente,
    criarCliente,
    atualizarCliente,
    deletarCliente,
    listarCidades
};

