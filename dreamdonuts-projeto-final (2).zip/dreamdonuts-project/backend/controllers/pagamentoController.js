const db = require('../database');

// Listar todos os pagamentos
async function listarPagamentos(req, res) {
    try {
        const result = await db.query(`
            SELECT 
                pg.PedidoIdPedido,
                pg.dataPagamento,
                pg.valorTotalPagamento,
                p.dataDoPedido,
                pc.nomePessoa as nomeCliente,
                pf.nomePessoa as nomeFuncionario
            FROM Pagamento pg
            JOIN Pedido p ON pg.PedidoIdPedido = p.idPedido
            LEFT JOIN Pessoa pc ON p.ClientePessoaCpfPessoa = pc.CpfPessoa
            LEFT JOIN Pessoa pf ON p.FuncionarioPessoaCpfPessoa = pf.CpfPessoa
            ORDER BY pg.dataPagamento DESC
        `);

        res.json({
            success: true,
            pagamentos: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar pagamentos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Obter pagamento por ID do pedido
async function obterPagamento(req, res) {
    try {
        const { pedidoId } = req.params;
        
        // Buscar dados do pagamento
        const pagamentoResult = await db.query(`
            SELECT 
                pg.PedidoIdPedido,
                pg.dataPagamento,
                pg.valorTotalPagamento,
                p.dataDoPedido,
                pc.nomePessoa as nomeCliente,
                pf.nomePessoa as nomeFuncionario
            FROM Pagamento pg
            JOIN Pedido p ON pg.PedidoIdPedido = p.idPedido
            LEFT JOIN Pessoa pc ON p.ClientePessoaCpfPessoa = pc.CpfPessoa
            LEFT JOIN Pessoa pf ON p.FuncionarioPessoaCpfPessoa = pf.CpfPessoa
            WHERE pg.PedidoIdPedido = $1
        `, [pedidoId]);

        if (pagamentoResult.rows.length === 0) {
            return res.status(404).json({ error: 'Pagamento não encontrado' });
        }

        // Buscar formas de pagamento utilizadas
        const formasResult = await db.query(`
            SELECT 
                phfp.FormaPagamentoIdFormaPagamento,
                fp.nomeFormaPagamento,
                phfp.valorPago
            FROM PagamentoHasFormaPagamento phfp
            JOIN FormaDePagamento fp ON phfp.FormaPagamentoIdFormaPagamento = fp.idFormaPagamento
            WHERE phfp.PagamentoIdPedido = $1
        `, [pedidoId]);

        const pagamento = pagamentoResult.rows[0];
        pagamento.formasPagamento = formasResult.rows;

        res.json({
            success: true,
            pagamento: pagamento
        });
    } catch (error) {
        console.error('Erro ao obter pagamento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Criar novo pagamento
async function criarPagamento(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { pedidoId, valorTotal, formasPagamento } = req.body;
        
        if (!pedidoId || !valorTotal || !formasPagamento || formasPagamento.length === 0) {
            return res.status(400).json({ error: 'Pedido, valor total e formas de pagamento são obrigatórios' });
        }

        // Verificar se o pedido existe
        const pedidoCheck = await client.query(
            'SELECT * FROM Pedido WHERE idPedido = $1',
            [pedidoId]
        );

        if (pedidoCheck.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }

        // Verificar se já existe pagamento para este pedido
        const pagamentoCheck = await client.query(
            'SELECT * FROM Pagamento WHERE PedidoIdPedido = $1',
            [pedidoId]
        );

        if (pagamentoCheck.rows.length > 0) {
            return res.status(400).json({ error: 'Pagamento já existe para este pedido' });
        }

        // Criar o pagamento
        const pagamentoResult = await client.query(
            'INSERT INTO Pagamento (PedidoIdPedido, valorTotalPagamento) VALUES ($1, $2) RETURNING *',
            [pedidoId, valorTotal]
        );

        // Adicionar formas de pagamento
        let totalFormas = 0;
        for (const forma of formasPagamento) {
            const { formaPagamentoId, valorPago } = forma;
            
            await client.query(
                'INSERT INTO PagamentoHasFormaPagamento (PagamentoIdPedido, FormaPagamentoIdFormaPagamento, valorPago) VALUES ($1, $2, $3)',
                [pedidoId, formaPagamentoId, valorPago]
            );

            totalFormas += parseFloat(valorPago);
        }

        // Verificar se o total das formas de pagamento bate com o valor total
        if (Math.abs(totalFormas - parseFloat(valorTotal)) > 0.01) {
            await client.query('ROLLBACK');
            return res.status(400).json({ 
                error: 'A soma das formas de pagamento deve ser igual ao valor total' 
            });
        }

        await client.query('COMMIT');

        res.status(201).json({
            success: true,
            pagamento: pagamentoResult.rows[0],
            message: 'Pagamento criado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao criar pagamento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Atualizar pagamento
async function atualizarPagamento(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { pedidoId } = req.params;
        const { valorTotal, formasPagamento } = req.body;
        
        if (!valorTotal || !formasPagamento || formasPagamento.length === 0) {
            return res.status(400).json({ error: 'Valor total e formas de pagamento são obrigatórios' });
        }

        // Verificar se o pagamento existe
        const pagamentoCheck = await client.query(
            'SELECT * FROM Pagamento WHERE PedidoIdPedido = $1',
            [pedidoId]
        );

        if (pagamentoCheck.rows.length === 0) {
            return res.status(404).json({ error: 'Pagamento não encontrado' });
        }

        // Atualizar o pagamento
        await client.query(
            'UPDATE Pagamento SET valorTotalPagamento = $1 WHERE PedidoIdPedido = $2',
            [valorTotal, pedidoId]
        );

        // Deletar formas de pagamento existentes
        await client.query(
            'DELETE FROM PagamentoHasFormaPagamento WHERE PagamentoIdPedido = $1',
            [pedidoId]
        );

        // Adicionar novas formas de pagamento
        let totalFormas = 0;
        for (const forma of formasPagamento) {
            const { formaPagamentoId, valorPago } = forma;
            
            await client.query(
                'INSERT INTO PagamentoHasFormaPagamento (PagamentoIdPedido, FormaPagamentoIdFormaPagamento, valorPago) VALUES ($1, $2, $3)',
                [pedidoId, formaPagamentoId, valorPago]
            );

            totalFormas += parseFloat(valorPago);
        }

        // Verificar se o total das formas de pagamento bate com o valor total
        if (Math.abs(totalFormas - parseFloat(valorTotal)) > 0.01) {
            await client.query('ROLLBACK');
            return res.status(400).json({ 
                error: 'A soma das formas de pagamento deve ser igual ao valor total' 
            });
        }

        await client.query('COMMIT');

        res.json({
            success: true,
            message: 'Pagamento atualizado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao atualizar pagamento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Deletar pagamento
async function deletarPagamento(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { pedidoId } = req.params;
        
        // Deletar formas de pagamento
        await client.query(
            'DELETE FROM PagamentoHasFormaPagamento WHERE PagamentoIdPedido = $1',
            [pedidoId]
        );
        
        // Deletar o pagamento
        const result = await client.query(
            'DELETE FROM Pagamento WHERE PedidoIdPedido = $1 RETURNING *',
            [pedidoId]
        );

        if (result.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Pagamento não encontrado' });
        }

        await client.query('COMMIT');

        res.json({
            success: true,
            message: 'Pagamento deletado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao deletar pagamento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Listar formas de pagamento para dropdown
async function listarFormasPagamento(req, res) {
    try {
        const result = await db.query('SELECT * FROM FormaDePagamento ORDER BY nomeFormaPagamento');
        res.json({
            success: true,
            formasPagamento: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar formas de pagamento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Listar pedidos sem pagamento para dropdown
async function listarPedidosSemPagamento(req, res) {
    try {
        const result = await db.query(`
            SELECT 
                p.idPedido,
                p.dataDoPedido,
                pc.nomePessoa as nomeCliente
            FROM Pedido p
            LEFT JOIN Pessoa pc ON p.ClientePessoaCpfPessoa = pc.CpfPessoa
            LEFT JOIN Pagamento pg ON p.idPedido = pg.PedidoIdPedido
            WHERE pg.PedidoIdPedido IS NULL
            ORDER BY p.dataDoPedido DESC
        `);

        res.json({
            success: true,
            pedidos: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar pedidos sem pagamento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    listarPagamentos,
    obterPagamento,
    criarPagamento,
    atualizarPagamento,
    deletarPagamento,
    listarFormasPagamento,
    listarPedidosSemPagamento
};

