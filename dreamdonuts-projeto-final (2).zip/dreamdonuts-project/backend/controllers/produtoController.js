const db = require('../database');

// Listar todos os produtos
async function listarProdutos(req, res) {
    try {
        const result = await db.query('SELECT * FROM Produto ORDER BY idProduto');
        res.json({
            success: true,
            produtos: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar produtos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Obter produto por ID
async function obterProduto(req, res) {
    try {
        const { id } = req.params;
        const result = await db.query('SELECT * FROM Produto WHERE idProduto = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }

        res.json({
            success: true,
            produto: result.rows[0]
        });
    } catch (error) {
        console.error('Erro ao obter produto:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Criar novo produto
async function criarProduto(req, res) {
    try {
        const { nomeProduto, quantidadeEmEstoque, precoUnitario } = req.body;
        
        if (!nomeProduto || precoUnitario === undefined) {
            return res.status(400).json({ error: 'Nome do produto e preço são obrigatórios' });
        }

        const result = await db.query(
            'INSERT INTO Produto (nomeProduto, quantidadeEmEstoque, precoUnitario) VALUES ($1, $2, $3) RETURNING *',
            [nomeProduto, quantidadeEmEstoque || 0, precoUnitario]
        );

        res.status(201).json({
            success: true,
            produto: result.rows[0],
            message: 'Produto criado com sucesso'
        });
    } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Atualizar produto
async function atualizarProduto(req, res) {
    try {
        const { id } = req.params;
        const { nomeProduto, quantidadeEmEstoque, precoUnitario } = req.body;
        
        if (!nomeProduto || precoUnitario === undefined) {
            return res.status(400).json({ error: 'Nome do produto e preço são obrigatórios' });
        }

        const result = await db.query(
            'UPDATE Produto SET nomeProduto = $1, quantidadeEmEstoque = $2, precoUnitario = $3 WHERE idProduto = $4 RETURNING *',
            [nomeProduto, quantidadeEmEstoque || 0, precoUnitario, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }

        res.json({
            success: true,
            produto: result.rows[0],
            message: 'Produto atualizado com sucesso'
        });
    } catch (error) {
        console.error('Erro ao atualizar produto:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Deletar produto
async function deletarProduto(req, res) {
    try {
        const { id } = req.params;
        
        // Verificar se o produto existe em pedidos
        const pedidoCheck = await db.query(
            'SELECT COUNT(*) FROM PedidoHasProduto WHERE ProdutoIdProduto = $1',
            [id]
        );

        if (parseInt(pedidoCheck.rows[0].count) > 0) {
            return res.status(400).json({ 
                error: 'Não é possível deletar produto que possui pedidos associados' 
            });
        }

        const result = await db.query(
            'DELETE FROM Produto WHERE idProduto = $1 RETURNING *',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }

        res.json({
            success: true,
            message: 'Produto deletado com sucesso'
        });
    } catch (error) {
        console.error('Erro ao deletar produto:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    listarProdutos,
    obterProduto,
    criarProduto,
    atualizarProduto,
    deletarProduto
};

