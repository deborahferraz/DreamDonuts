// Controlador do menu principal
async function getMenuData(req, res) {
    try {
        const userSession = req.cookies.userSession;
        
        if (!userSession) {
            return res.status(401).json({ error: 'Usuário não logado' });
        }

        // Dados do menu baseados no cargo do usuário
        const menuItems = [
            {
                id: 'produtos',
                title: 'Produtos',
                description: 'Gerenciar produtos da loja',
                icon: '🍩',
                url: '/produto/produto.html',
                permissions: ['Vendedor', 'Gerente', 'Caixa']
            },
            {
                id: 'pedidos',
                title: 'Pedidos',
                description: 'Gerenciar pedidos dos clientes',
                icon: '📋',
                url: '/pedido/pedido.html',
                permissions: ['Vendedor', 'Gerente', 'Caixa']
            },
            {
                id: 'clientes',
                title: 'Clientes',
                description: 'Gerenciar clientes',
                icon: '👥',
                url: '/cliente/cliente.html',
                permissions: ['Vendedor', 'Gerente']
            },
            {
                id: 'funcionarios',
                title: 'Funcionários',
                description: 'Gerenciar funcionários',
                icon: '👨‍💼',
                url: '/funcionario/funcionario.html',
                permissions: ['Gerente']
            },
            {
                id: 'pagamentos',
                title: 'Pagamentos',
                description: 'Gerenciar pagamentos',
                icon: '💳',
                url: '/pagamento/pagamento.html',
                permissions: ['Vendedor', 'Gerente', 'Caixa']
            }
        ];

        // Filtrar itens do menu baseado nas permissões do usuário
        const filteredMenu = menuItems.filter(item => 
            item.permissions.includes(userSession.cargo)
        );

        res.json({
            success: true,
            user: userSession,
            menuItems: filteredMenu
        });

    } catch (error) {
        console.error('Erro ao obter dados do menu:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    getMenuData
};

