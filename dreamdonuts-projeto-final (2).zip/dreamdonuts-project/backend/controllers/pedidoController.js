const db = require('../database');

// Listar todos os pedidos com informações relacionadas
async function listarPedidos(req, res) {
    try {
        const result = await db.query(`
            SELECT 
                p.idPedido,
                p.dataDoPedido,
                p.ClientePessoaCpfPessoa,
                pc.nomePessoa as nomeCliente,
                p.FuncionarioPessoaCpfPessoa,
                pf.nomePessoa as nomeFuncionario,
                COALESCE(pg.valorTotalPagamento, 0) as valorTotal
            FROM Pedido p
            LEFT JOIN Pessoa pc ON p.ClientePessoaCpfPessoa = pc.CpfPessoa
            LEFT JOIN Pessoa pf ON p.FuncionarioPessoaCpfPessoa = pf.CpfPessoa
            LEFT JOIN Pagamento pg ON p.idPedido = pg.PedidoIdPedido
            ORDER BY p.idPedido DESC
        `);

        res.json({
            success: true,
            pedidos: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar pedidos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Obter pedido por ID com itens
async function obterPedido(req, res) {
    try {
        const { id } = req.params;
        
        // Buscar dados do pedido
        const pedidoResult = await db.query(`
            SELECT 
                p.idPedido,
                p.dataDoPedido,
                p.ClientePessoaCpfPessoa,
                pc.nomePessoa as nomeCliente,
                p.FuncionarioPessoaCpfPessoa,
                pf.nomePessoa as nomeFuncionario
            FROM Pedido p
            LEFT JOIN Pessoa pc ON p.ClientePessoaCpfPessoa = pc.CpfPessoa
            LEFT JOIN Pessoa pf ON p.FuncionarioPessoaCpfPessoa = pf.CpfPessoa
            WHERE p.idPedido = $1
        `, [id]);

        if (pedidoResult.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }

        // Buscar itens do pedido
        const itensResult = await db.query(`
            SELECT 
                php.ProdutoIdProduto,
                pr.nomeProduto,
                php.quantidade,
                php.precoUnitario,
                (php.quantidade * php.precoUnitario) as subtotal
            FROM PedidoHasProduto php
            JOIN Produto pr ON php.ProdutoIdProduto = pr.idProduto
            WHERE php.PedidoIdPedido = $1
        `, [id]);

        const pedido = pedidoResult.rows[0];
        pedido.itens = itensResult.rows;

        res.json({
            success: true,
            pedido: pedido
        });
    } catch (error) {
        console.error('Erro ao obter pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Criar novo pedido
async function criarPedido(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { clienteCpf, funcionarioCpf, itens } = req.body;
        
        if (!funcionarioCpf || !itens || itens.length === 0) {
            return res.status(400).json({ error: 'Funcionário e itens são obrigatórios' });
        }

        // Criar o pedido
        const pedidoResult = await client.query(
            'INSERT INTO Pedido (dataDoPedido, ClientePessoaCpfPessoa, FuncionarioPessoaCpfPessoa) VALUES (CURRENT_DATE, $1, $2) RETURNING *',
            [clienteCpf || null, funcionarioCpf]
        );

        const pedidoId = pedidoResult.rows[0].idpedido;
        let valorTotal = 0;

        // Adicionar itens do pedido
        for (const item of itens) {
            const { produtoId, quantidade, precoUnitario } = item;
            
            await client.query(
                'INSERT INTO PedidoHasProduto (ProdutoIdProduto, PedidoIdPedido, quantidade, precoUnitario) VALUES ($1, $2, $3, $4)',
                [produtoId, pedidoId, quantidade, precoUnitario]
            );

            valorTotal += quantidade * precoUnitario;

            // Atualizar estoque
            await client.query(
                'UPDATE Produto SET quantidadeEmEstoque = quantidadeEmEstoque - $1 WHERE idProduto = $2',
                [quantidade, produtoId]
            );
        }

        // Criar registro de pagamento
        await client.query(
            'INSERT INTO Pagamento (PedidoIdPedido, valorTotalPagamento) VALUES ($1, $2)',
            [pedidoId, valorTotal]
        );

        await client.query('COMMIT');

        res.status(201).json({
            success: true,
            pedido: pedidoResult.rows[0],
            message: 'Pedido criado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao criar pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Atualizar pedido
async function atualizarPedido(req, res) {
    try {
        const { id } = req.params;
        const { clienteCpf, funcionarioCpf } = req.body;
        
        const result = await db.query(
            'UPDATE Pedido SET ClientePessoaCpfPessoa = $1, FuncionarioPessoaCpfPessoa = $2 WHERE idPedido = $3 RETURNING *',
            [clienteCpf || null, funcionarioCpf, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }

        res.json({
            success: true,
            pedido: result.rows[0],
            message: 'Pedido atualizado com sucesso'
        });
    } catch (error) {
        console.error('Erro ao atualizar pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Deletar pedido
async function deletarPedido(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { id } = req.params;
        
        // Deletar pagamentos relacionados
        await client.query('DELETE FROM PagamentoHasFormaPagamento WHERE PagamentoIdPedido = $1', [id]);
        await client.query('DELETE FROM Pagamento WHERE PedidoIdPedido = $1', [id]);
        
        // Deletar itens do pedido
        await client.query('DELETE FROM PedidoHasProduto WHERE PedidoIdPedido = $1', [id]);
        
        // Deletar o pedido
        const result = await client.query('DELETE FROM Pedido WHERE idPedido = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }

        await client.query('COMMIT');

        res.json({
            success: true,
            message: 'Pedido deletado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao deletar pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Listar clientes para dropdown
async function listarClientes(req, res) {
    try {
        const result = await db.query(`
            SELECT c.PessoaCpfPessoa, p.nomePessoa 
            FROM Cliente c 
            JOIN Pessoa p ON c.PessoaCpfPessoa = p.CpfPessoa 
            ORDER BY p.nomePessoa
        `);

        res.json({
            success: true,
            clientes: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar clientes:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Listar funcionários para dropdown
async function listarFuncionarios(req, res) {
    try {
        const result = await db.query(`
            SELECT f.PessoaCpfPessoa, p.nomePessoa 
            FROM Funcionario f 
            JOIN Pessoa p ON f.PessoaCpfPessoa = p.CpfPessoa 
            ORDER BY p.nomePessoa
        `);

        res.json({
            success: true,
            funcionarios: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar funcionários:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    listarPedidos,
    obterPedido,
    criarPedido,
    atualizarPedido,
    deletarPedido,
    listarClientes,
    listarFuncionarios
};

