const db = require('../database');

// Listar todos os funcionários
async function listarFuncionarios(req, res) {
    try {
        const result = await db.query(`
            SELECT 
                f.PessoaCpfPessoa,
                p.nomePessoa,
                p.dataNascimentoPessoa,
                f.salario,
                f.porcentagemComissao,
                c.nomeCargo,
                f.CargoIdCargo
            FROM Funcionario f
            JOIN Pessoa p ON f.PessoaCpfPessoa = p.CpfPessoa
            JOIN Cargo c ON f.CargoIdCargo = c.idCargo
            ORDER BY p.nomePessoa
        `);

        res.json({
            success: true,
            funcionarios: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar funcionários:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Obter funcionário por CPF
async function obterFuncionario(req, res) {
    try {
        const { cpf } = req.params;
        const result = await db.query(`
            SELECT 
                f.PessoaCpfPessoa,
                p.nomePessoa,
                p.dataNascimentoPessoa,
                f.salario,
                f.porcentagemComissao,
                f.CargoIdCargo,
                c.nomeCargo
            FROM Funcionario f
            JOIN Pessoa p ON f.PessoaCpfPessoa = p.CpfPessoa
            JOIN Cargo c ON f.CargoIdCargo = c.idCargo
            WHERE f.PessoaCpfPessoa = $1
        `, [cpf]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Funcionário não encontrado' });
        }

        res.json({
            success: true,
            funcionario: result.rows[0]
        });
    } catch (error) {
        console.error('Erro ao obter funcionário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

// Criar novo funcionário
async function criarFuncionario(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { 
            cpf, 
            nome, 
            dataNascimento, 
            salario, 
            cargoId, 
            porcentagemComissao 
        } = req.body;
        
        if (!cpf || !nome || !cargoId) {
            return res.status(400).json({ error: 'CPF, nome e cargo são obrigatórios' });
        }

        // Criar pessoa
        await client.query(
            'INSERT INTO Pessoa (CpfPessoa, nomePessoa, dataNascimentoPessoa) VALUES ($1, $2, $3)',
            [cpf, nome, dataNascimento || null]
        );

        // Criar funcionário
        const funcionarioResult = await client.query(
            'INSERT INTO Funcionario (PessoaCpfPessoa, salario, CargoIdCargo, porcentagemComissao) VALUES ($1, $2, $3, $4) RETURNING *',
            [cpf, salario || null, cargoId, porcentagemComissao || null]
        );

        await client.query('COMMIT');

        res.status(201).json({
            success: true,
            funcionario: funcionarioResult.rows[0],
            message: 'Funcionário criado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao criar funcionário:', error);
        
        if (error.code === '23505') { // Violação de chave única
            res.status(400).json({ error: 'CPF já cadastrado' });
        } else {
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    } finally {
        client.release();
    }
}

// Atualizar funcionário
async function atualizarFuncionario(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { cpf } = req.params;
        const { 
            nome, 
            dataNascimento, 
            salario, 
            cargoId, 
            porcentagemComissao 
        } = req.body;
        
        if (!nome || !cargoId) {
            return res.status(400).json({ error: 'Nome e cargo são obrigatórios' });
        }

        // Verificar se funcionário existe
        const funcionarioCheck = await client.query(
            'SELECT * FROM Funcionario WHERE PessoaCpfPessoa = $1',
            [cpf]
        );

        if (funcionarioCheck.rows.length === 0) {
            return res.status(404).json({ error: 'Funcionário não encontrado' });
        }

        // Atualizar pessoa
        await client.query(
            'UPDATE Pessoa SET nomePessoa = $1, dataNascimentoPessoa = $2 WHERE CpfPessoa = $3',
            [nome, dataNascimento || null, cpf]
        );

        // Atualizar funcionário
        const result = await client.query(
            'UPDATE Funcionario SET salario = $1, CargoIdCargo = $2, porcentagemComissao = $3 WHERE PessoaCpfPessoa = $4 RETURNING *',
            [salario || null, cargoId, porcentagemComissao || null, cpf]
        );

        await client.query('COMMIT');

        res.json({
            success: true,
            funcionario: result.rows[0],
            message: 'Funcionário atualizado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao atualizar funcionário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Deletar funcionário
async function deletarFuncionario(req, res) {
    const client = await db.getClient();
    
    try {
        await client.query('BEGIN');
        
        const { cpf } = req.params;
        
        // Verificar se funcionário tem pedidos
        const pedidoCheck = await client.query(
            'SELECT COUNT(*) FROM Pedido WHERE FuncionarioPessoaCpfPessoa = $1',
            [cpf]
        );

        if (parseInt(pedidoCheck.rows[0].count) > 0) {
            return res.status(400).json({ 
                error: 'Não é possível deletar funcionário que possui pedidos associados' 
            });
        }

        // Deletar funcionário
        const funcionarioResult = await client.query(
            'DELETE FROM Funcionario WHERE PessoaCpfPessoa = $1 RETURNING *',
            [cpf]
        );

        if (funcionarioResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Funcionário não encontrado' });
        }

        // Deletar pessoa
        await client.query('DELETE FROM Pessoa WHERE CpfPessoa = $1', [cpf]);

        await client.query('COMMIT');

        res.json({
            success: true,
            message: 'Funcionário deletado com sucesso'
        });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Erro ao deletar funcionário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    } finally {
        client.release();
    }
}

// Listar cargos para dropdown
async function listarCargos(req, res) {
    try {
        const result = await db.query('SELECT * FROM Cargo ORDER BY nomeCargo');
        res.json({
            success: true,
            cargos: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar cargos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
}

module.exports = {
    listarFuncionarios,
    obterFuncionario,
    criarFuncionario,
    atualizarFuncionario,
    deletarFuncionario,
    listarCargos
};

