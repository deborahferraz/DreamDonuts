// Configuração da API
const API_BASE_URL = '/api';

// Elementos DOM
const loginScreen = document.getElementById('loginScreen');
const mainScreen = document.getElementById('mainScreen');
const loginForm = document.getElementById('loginForm');
const userName = document.getElementById('userName');
const userRole = document.getElementById('userRole');
const logoutBtn = document.getElementById('logoutBtn');
const menuGrid = document.getElementById('menuGrid');
const notificationModal = document.getElementById('notificationModal');
const notificationMessage = document.getElementById('notificationMessage');

// Estado da aplicação
let currentUser = null;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Inicializar aplicação
async function initializeApp() {
    try {
        // Verificar se o usuário já está logado
        const response = await fetch(`${API_BASE_URL}/login/verificar`, {
            credentials: 'include'
        });

        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                currentUser = data.user;
                showMainScreen();
                return;
            }
        }
    } catch (error) {
        console.error('Erro ao verificar login:', error);
    }

    // Mostrar tela de login
    showLoginScreen();
}

// Mostrar tela de login
function showLoginScreen() {
    loginScreen.style.display = 'flex';
    mainScreen.style.display = 'none';
    
    // Event listeners
    loginForm.addEventListener('submit', handleLogin);
}

// Mostrar tela principal
async function showMainScreen() {
    loginScreen.style.display = 'none';
    mainScreen.style.display = 'flex';
    
    // Atualizar informações do usuário
    userName.textContent = currentUser.nome;
    userRole.textContent = currentUser.cargo;
    
    // Carregar menu
    await loadMenu();
    
    // Event listeners
    logoutBtn.addEventListener('click', handleLogout);
}

// Manipular login
async function handleLogin(event) {
    event.preventDefault();
    
    const formData = new FormData(loginForm);
    const loginData = {
        email: formData.get('email'),
        senha: formData.get('senha')
    };

    try {
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify(loginData)
        });

        const data = await response.json();

        if (data.success) {
            currentUser = data.user;
            showNotification('Login realizado com sucesso!', 'success');
            showMainScreen();
        } else {
            showNotification(data.error || 'Erro no login', 'error');
        }
    } catch (error) {
        console.error('Erro no login:', error);
        showNotification('Erro de conexão', 'error');
    }
}

// Manipular logout
async function handleLogout() {
    try {
        const response = await fetch(`${API_BASE_URL}/login/logout`, {
            method: 'POST',
            credentials: 'include'
        });

        const data = await response.json();

        if (data.success) {
            currentUser = null;
            showNotification('Logout realizado com sucesso!', 'success');
            showLoginScreen();
        }
    } catch (error) {
        console.error('Erro no logout:', error);
        showNotification('Erro no logout', 'error');
    }
}

// Carregar menu
async function loadMenu() {
    try {
        const response = await fetch(`${API_BASE_URL}/menu`, {
            credentials: 'include'
        });

        const data = await response.json();

        if (data.success) {
            renderMenu(data.menuItems);
        } else {
            showNotification('Erro ao carregar menu', 'error');
        }
    } catch (error) {
        console.error('Erro ao carregar menu:', error);
        showNotification('Erro de conexão', 'error');
    }
}

// Renderizar menu
function renderMenu(menuItems) {
    menuGrid.innerHTML = '';

    if (menuItems.length === 0) {
        menuGrid.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-circle"></i>
                <h3>Nenhum item disponível</h3>
                <p>Você não tem permissão para acessar nenhum módulo.</p>
            </div>
        `;
        return;
    }

    menuItems.forEach(item => {
        const menuItem = document.createElement('a');
        menuItem.className = 'menu-item';
        menuItem.href = item.url;
        
        menuItem.innerHTML = `
            <span class="menu-icon">${item.icon}</span>
            <h3 class="menu-title">${item.title}</h3>
            <p class="menu-description">${item.description}</p>
        `;

        menuGrid.appendChild(menuItem);
    });
}

// Mostrar notificação
function showNotification(message, type = 'info') {
    notificationMessage.textContent = message;
    
    const content = notificationModal.querySelector('.notification-content');
    content.className = `notification-content ${type}`;
    
    notificationModal.classList.add('show');
    
    setTimeout(() => {
        notificationModal.classList.remove('show');
    }, 3000);
}

// Função utilitária para fazer requisições à API
async function apiRequest(endpoint, options = {}) {
    const defaultOptions = {
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json'
        }
    };

    const finalOptions = { ...defaultOptions, ...options };

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, finalOptions);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Erro na requisição');
        }

        return data;
    } catch (error) {
        console.error('Erro na API:', error);
        throw error;
    }
}

// Função para formatar CPF
function formatCPF(cpf) {
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

// Função para formatar data
function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Função para formatar moeda
function formatCurrency(value) {
    if (value === null || value === undefined) return '';
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

// Função para validar CPF
function validateCPF(cpf) {
    cpf = cpf.replace(/[^\d]/g, '');
    
    if (cpf.length !== 11) return false;
    
    // Verificar se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(cpf)) return false;
    
    // Validar dígitos verificadores
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let digit1 = 11 - (sum % 11);
    if (digit1 > 9) digit1 = 0;
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
    }
    let digit2 = 11 - (sum % 11);
    if (digit2 > 9) digit2 = 0;
    
    return digit1 === parseInt(cpf.charAt(9)) && digit2 === parseInt(cpf.charAt(10));
}

// Exportar funções para uso global
window.apiRequest = apiRequest;
window.showNotification = showNotification;
window.formatCPF = formatCPF;
window.formatDate = formatDate;
window.formatCurrency = formatCurrency;
window.validateCPF = validateCPF;

