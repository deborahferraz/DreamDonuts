// Variáveis globais
let cart = [];
let cartCount = 0;

// Elementos DOM
const searchInput = document.querySelector('.search-input');
const searchBtn = document.querySelector('.search-btn');
const cartBtn = document.querySelector('.cart-btn');
const cartCountElement = document.querySelector('.cart-count');
const signupBtn = document.querySelector('.signup-btn');
const loginBtn = document.querySelector('.login-btn');
const paymentBtn = document.querySelector('.payment-btn');
const addToCartBtns = document.querySelectorAll('.add-to-cart-btn');

// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    initializeAnimations();
    loadCartFromStorage();
});

// Configurar event listeners
function initializeEventListeners() {
    // Pesquisa
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });

    // Botões de navegação
    cartBtn.addEventListener('click', showCart);
    signupBtn.addEventListener('click', showSignupModal);
    loginBtn.addEventListener('click', showLoginModal);
    paymentBtn.addEventListener('click', showPaymentModal);

    // Botões de adicionar ao carrinho
    addToCartBtns.forEach((btn, index) => {
        btn.addEventListener('click', () => addToCart(index));
    });

    // Animação de scroll suave para links internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Função de pesquisa
function handleSearch() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (searchTerm === '') {
        showNotification('Digite algo para pesquisar!', 'warning');
        return;
    }

    // Simular pesquisa
    showNotification(`Pesquisando por "${searchTerm}"...`, 'info');
    
    // Limpar campo de pesquisa
    searchInput.value = '';
    
    // Simular resultados após 1 segundo
    setTimeout(() => {
        const results = searchDonuts(searchTerm);
        displaySearchResults(results, searchTerm);
    }, 1000);
}

// Simular busca de donuts
function searchDonuts(term) {
    const donuts = [
        { name: 'Donut Arco-íris', price: 6.23, image: 'images/donut_colorful_1.jpg' },
        { name: 'Donut Chocolate Especial', price: 7.43, image: 'images/donut_fun_1.jpg' },
        { name: 'Donut Glacê Rosa', price: 6.32, image: 'images/donut_covered_1.jpg' },
        { name: 'Donut Morango', price: 5.90, image: 'images/donut_fun_2.jpg' },
        { name: 'Donut Baunilha', price: 5.50, image: 'images/donut_covered_2.jpg' }
    ];

    return donuts.filter(donut => 
        donut.name.toLowerCase().includes(term) ||
        term.includes('chocolate') && donut.name.includes('Chocolate') ||
        term.includes('rosa') && donut.name.includes('Rosa') ||
        term.includes('arco') && donut.name.includes('Arco')
    );
}

// Exibir resultados da pesquisa
function displaySearchResults(results, searchTerm) {
    if (results.length === 0) {
        showNotification(`Nenhum donut encontrado para "${searchTerm}"`, 'error');
        return;
    }

    showNotification(`${results.length} donut(s) encontrado(s)!`, 'success');
    
    // Scroll para a seção de promoções
    document.querySelector('.promotions').scrollIntoView({
        behavior: 'smooth'
    });
}

// Adicionar item ao carrinho
function addToCart(productIndex) {
    const products = [
        { 
            id: 1, 
            name: 'Donut Arco-íris', 
            price: 6.23, 
            image: 'images/donut_colorful_1.jpg',
            description: 'Delicioso donut com cobertura colorida'
        },
        { 
            id: 2, 
            name: 'Donut Chocolate Especial', 
            price: 7.43, 
            image: 'images/donut_fun_1.jpg',
            description: 'Cobertura de chocolate premium'
        },
        { 
            id: 3, 
            name: 'Donut Glacê Rosa', 
            price: 6.32, 
            image: 'images/donut_covered_1.jpg',
            description: 'Massa fofinha com glacê rosa'
        }
    ];

    const product = products[productIndex];
    
    // Verificar se o produto já está no carrinho
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }

    cartCount++;
    updateCartDisplay();
    saveCartToStorage();
    
    showNotification(`${product.name} adicionado ao carrinho!`, 'success');
    
    // Animação do botão
    const btn = addToCartBtns[productIndex];
    btn.style.transform = 'scale(0.95)';
    setTimeout(() => {
        btn.style.transform = 'scale(1)';
    }, 150);
}

// Atualizar exibição do carrinho
function updateCartDisplay() {
    cartCountElement.textContent = cartCount;
    
    if (cartCount > 0) {
        cartCountElement.style.display = 'inline-block';
        cartBtn.classList.add('has-items');
    } else {
        cartCountElement.style.display = 'none';
        cartBtn.classList.remove('has-items');
    }
}

// Mostrar carrinho
function showCart() {
    if (cart.length === 0) {
        showNotification('Seu carrinho está vazio!', 'info');
        return;
    }

    let cartHTML = `
        <div class="cart-modal">
            <div class="cart-content">
                <div class="cart-header">
                    <h2>🛒 Seu Carrinho</h2>
                    <button class="close-cart" onclick="closeModal()">&times;</button>
                </div>
                <div class="cart-items">
    `;

    let total = 0;
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        cartHTML += `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <div class="item-details">
                    <h3>${item.name}</h3>
                    <p>${item.description}</p>
                    <div class="quantity-controls">
                        <button onclick="updateQuantity(${index}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="updateQuantity(${index}, 1)">+</button>
                    </div>
                </div>
                <div class="item-price">
                    <span>R$ ${itemTotal.toFixed(2)}</span>
                    <button onclick="removeFromCart(${index})" class="remove-btn">🗑️</button>
                </div>
            </div>
        `;
    });

    cartHTML += `
                </div>
                <div class="cart-footer">
                    <div class="cart-total">
                        <strong>Total: R$ ${total.toFixed(2)}</strong>
                    </div>
                    <button class="checkout-btn" onclick="proceedToCheckout()">
                        Finalizar Pedido
                    </button>
                </div>
            </div>
        </div>
    `;

    showModal(cartHTML);
}

// Atualizar quantidade no carrinho
function updateQuantity(index, change) {
    cart[index].quantity += change;
    
    if (cart[index].quantity <= 0) {
        removeFromCart(index);
        return;
    }
    
    saveCartToStorage();
    showCart(); // Recarregar o modal do carrinho
}

// Remover item do carrinho
function removeFromCart(index) {
    const removedItem = cart[index];
    cartCount -= removedItem.quantity;
    cart.splice(index, 1);
    
    updateCartDisplay();
    saveCartToStorage();
    
    showNotification(`${removedItem.name} removido do carrinho!`, 'info');
    
    if (cart.length === 0) {
        closeModal();
    } else {
        showCart(); // Recarregar o modal do carrinho
    }
}

// Prosseguir para checkout
function proceedToCheckout() {
    closeModal();
    showPaymentModal();
}

// Mostrar modal de cadastro
function showSignupModal() {
    const signupHTML = `
        <div class="auth-modal">
            <div class="auth-content">
                <div class="auth-header">
                    <h2>🍩 Criar Conta</h2>
                    <button class="close-modal" onclick="closeModal()">&times;</button>
                </div>
                <form class="auth-form" onsubmit="handleSignup(event)">
                    <div class="form-group">
                        <label>Nome Completo</label>
                        <input type="text" required placeholder="Seu nome completo">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" required placeholder="seu@email.com">
                    </div>
                    <div class="form-group">
                        <label>Senha</label>
                        <input type="password" required placeholder="Sua senha">
                    </div>
                    <div class="form-group">
                        <label>Confirmar Senha</label>
                        <input type="password" required placeholder="Confirme sua senha">
                    </div>
                    <button type="submit" class="auth-btn">Criar Conta</button>
                </form>
                <p class="auth-switch">
                    Já tem conta? <a href="#" onclick="showLoginModal()">Faça login</a>
                </p>
            </div>
        </div>
    `;
    showModal(signupHTML);
}

// Mostrar modal de login
function showLoginModal() {
    const loginHTML = `
        <div class="auth-modal">
            <div class="auth-content">
                <div class="auth-header">
                    <h2>🍩 Entrar</h2>
                    <button class="close-modal" onclick="closeModal()">&times;</button>
                </div>
                <form class="auth-form" onsubmit="handleLogin(event)">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" required placeholder="seu@email.com">
                    </div>
                    <div class="form-group">
                        <label>Senha</label>
                        <input type="password" required placeholder="Sua senha">
                    </div>
                    <button type="submit" class="auth-btn">Entrar</button>
                </form>
                <p class="auth-switch">
                    Não tem conta? <a href="#" onclick="showSignupModal()">Cadastre-se</a>
                </p>
            </div>
        </div>
    `;
    showModal(loginHTML);
}

// Mostrar modal de pagamento
function showPaymentModal() {
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    const paymentHTML = `
        <div class="payment-modal">
            <div class="payment-content">
                <div class="payment-header">
                    <h2>💳 Pagamento</h2>
                    <button class="close-modal" onclick="closeModal()">&times;</button>
                </div>
                <div class="payment-summary">
                    <h3>Resumo do Pedido</h3>
                    <p>Total: <strong>R$ ${total.toFixed(2)}</strong></p>
                </div>
                <form class="payment-form" onsubmit="handlePayment(event)">
                    <div class="form-group">
                        <label>Número do Cartão</label>
                        <input type="text" required placeholder="1234 5678 9012 3456" maxlength="19">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Validade</label>
                            <input type="text" required placeholder="MM/AA" maxlength="5">
                        </div>
                        <div class="form-group">
                            <label>CVV</label>
                            <input type="text" required placeholder="123" maxlength="3">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Nome no Cartão</label>
                        <input type="text" required placeholder="Nome como no cartão">
                    </div>
                    <button type="submit" class="payment-btn-submit">
                        Finalizar Pagamento - R$ ${total.toFixed(2)}
                    </button>
                </form>
            </div>
        </div>
    `;
    showModal(paymentHTML);
}

// Manipular cadastro
function handleSignup(event) {
    event.preventDefault();
    showNotification('Conta criada com sucesso! 🎉', 'success');
    closeModal();
}

// Manipular login
function handleLogin(event) {
    event.preventDefault();
    showNotification('Login realizado com sucesso! 👋', 'success');
    closeModal();
}

// Manipular pagamento
function handlePayment(event) {
    event.preventDefault();
    
    // Simular processamento
    showNotification('Processando pagamento...', 'info');
    
    setTimeout(() => {
        cart = [];
        cartCount = 0;
        updateCartDisplay();
        saveCartToStorage();
        
        closeModal();
        showNotification('Pagamento realizado com sucesso! Seu pedido está sendo preparado! 🍩✨', 'success');
    }, 2000);
}

// Mostrar modal genérico
function showModal(content) {
    // Remover modal existente se houver
    const existingModal = document.querySelector('.modal-overlay');
    if (existingModal) {
        existingModal.remove();
    }

    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    modalOverlay.innerHTML = content;
    
    document.body.appendChild(modalOverlay);
    
    // Adicionar event listener para fechar ao clicar fora
    modalOverlay.addEventListener('click', function(e) {
        if (e.target === modalOverlay) {
            closeModal();
        }
    });
    
    // Animação de entrada
    setTimeout(() => {
        modalOverlay.classList.add('show');
    }, 10);
}

// Fechar modal
function closeModal() {
    const modalOverlay = document.querySelector('.modal-overlay');
    if (modalOverlay) {
        modalOverlay.classList.remove('show');
        setTimeout(() => {
            modalOverlay.remove();
        }, 300);
    }
}

// Mostrar notificação
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Mostrar notificação
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Remover notificação após 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Salvar carrinho no localStorage
function saveCartToStorage() {
    localStorage.setItem('dreamdonuts_cart', JSON.stringify(cart));
    localStorage.setItem('dreamdonuts_cart_count', cartCount.toString());
}

// Carregar carrinho do localStorage
function loadCartFromStorage() {
    const savedCart = localStorage.getItem('dreamdonuts_cart');
    const savedCount = localStorage.getItem('dreamdonuts_cart_count');
    
    if (savedCart) {
        cart = JSON.parse(savedCart);
    }
    
    if (savedCount) {
        cartCount = parseInt(savedCount);
    }
    
    updateCartDisplay();
}

// Inicializar animações
function initializeAnimations() {
    // Animação de scroll reveal
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observar elementos para animação
    document.querySelectorAll('.promo-card, .about-content, .feature').forEach(el => {
        observer.observe(el);
    });

    // Efeito parallax suave no hero
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
    });
}

// CSS adicional para modais e notificações (será injetado dinamicamente)
const additionalCSS = `
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .modal-overlay.show {
        opacity: 1;
    }

    .cart-content, .auth-content, .payment-content {
        background: white;
        border-radius: 20px;
        max-width: 500px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
        transform: translateY(50px);
        transition: transform 0.3s ease;
    }

    .modal-overlay.show .cart-content,
    .modal-overlay.show .auth-content,
    .modal-overlay.show .payment-content {
        transform: translateY(0);
    }

    .cart-header, .auth-header, .payment-header {
        padding: 20px;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .close-modal, .close-cart {
        background: none;
        border: none;
        font-size: 2rem;
        cursor: pointer;
        color: #999;
    }

    .cart-items {
        padding: 20px;
    }

    .cart-item {
        display: flex;
        gap: 15px;
        padding: 15px 0;
        border-bottom: 1px solid #eee;
    }

    .cart-item img {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 10px;
    }

    .item-details {
        flex: 1;
    }

    .quantity-controls {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 10px;
    }

    .quantity-controls button {
        background: var(--primary-pink);
        color: white;
        border: none;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        cursor: pointer;
    }

    .cart-footer {
        padding: 20px;
        border-top: 1px solid #eee;
    }

    .checkout-btn, .auth-btn, .payment-btn-submit {
        width: 100%;
        background: var(--gradient-pink);
        color: white;
        border: none;
        padding: 15px;
        border-radius: 10px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        margin-top: 15px;
    }

    .auth-form, .payment-form {
        padding: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 600;
    }

    .form-group input {
        width: 100%;
        padding: 12px;
        border: 2px solid #eee;
        border-radius: 8px;
        font-size: 1rem;
    }

    .form-row {
        display: flex;
        gap: 15px;
    }

    .notification {
        position: fixed;
        top: 100px;
        right: 20px;
        background: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        z-index: 10001;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 300px;
    }

    .notification.show {
        transform: translateX(0);
    }

    .notification.success {
        border-left: 4px solid #4CAF50;
    }

    .notification.error {
        border-left: 4px solid #f44336;
    }

    .notification.warning {
        border-left: 4px solid #ff9800;
    }

    .notification.info {
        border-left: 4px solid #2196F3;
    }

    .animate-in {
        animation: fadeInUp 0.6s ease-out;
    }
`;

// Injetar CSS adicional
const style = document.createElement('style');
style.textContent = additionalCSS;
document.head.appendChild(style);

