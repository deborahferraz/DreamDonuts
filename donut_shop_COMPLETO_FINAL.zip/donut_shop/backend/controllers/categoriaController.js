const db = require('../database');

// Listar todas as categorias
const listarCategorias = async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM categorias ORDER BY nome_categoria');
        res.json(result.rows);
    } catch (error) {
        console.error('Erro ao listar categorias:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Buscar categoria por ID
const buscarCategoriaPorId = async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('SELECT * FROM categorias WHERE id_categoria = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Categoria não encontrada' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao buscar categoria:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar nova categoria
const criarCategoria = async (req, res) => {
    try {
        const { nome_categoria, descricao_categoria } = req.body;
        
        const result = await db.query(
            'INSERT INTO categorias (nome_categoria, descricao_categoria) VALUES ($1, $2) RETURNING *',
            [nome_categoria, descricao_categoria]
        );
        
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao criar categoria:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar categoria
const atualizarCategoria = async (req, res) => {
    try {
        const { id } = req.params;
        const { nome_categoria, descricao_categoria } = req.body;
        
        const result = await db.query(
            'UPDATE categorias SET nome_categoria = $1, descricao_categoria = $2 WHERE id_categoria = $3 RETURNING *',
            [nome_categoria, descricao_categoria, id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Categoria não encontrada' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao atualizar categoria:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar categoria
const deletarCategoria = async (req, res) => {
    try {
        const { id } = req.params;
        
        const result = await db.query('DELETE FROM categorias WHERE id_categoria = $1 RETURNING id_categoria', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Categoria não encontrada' });
        }
        
        res.json({ message: 'Categoria deletada com sucesso' });
    } catch (error) {
        console.error('Erro ao deletar categoria:', error);
        
        // Verificar se é erro de violação de foreign key
        if (error.code === '23503') {
            return res.status(400).json({
                error: 'Não é possível deletar categoria que possui produtos associados'
            });
        }
        
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = {
    listarCategorias,
    buscarCategoriaPorId,
    criarCategoria,
    atualizarCategoria,
    deletarCategoria
};

