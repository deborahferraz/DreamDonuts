const db = require('../database');

// Listar todos os pedidos
const listarPedidos = async (req, res) => {
    try {
        const result = await db.query(`
            SELECT p.*, u.nome_usuario 
            FROM pedidos p 
            LEFT JOIN usuarios u ON p.usuario_id = u.id_usuario 
            ORDER BY p.data_pedido DESC
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Erro ao listar pedidos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Buscar pedido por ID com itens
const buscarPedidoPorId = async (req, res) => {
    try {
        const { id } = req.params;
        
        // Buscar dados do pedido
        const pedidoResult = await db.query(`
            SELECT p.*, u.nome_usuario 
            FROM pedidos p 
            LEFT JOIN usuarios u ON p.usuario_id = u.id_usuario 
            WHERE p.id_pedido = $1
        `, [id]);
        
        if (pedidoResult.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        
        // Buscar itens do pedido
        const itensResult = await db.query(`
            SELECT ip.*, pr.nome_produto, pr.descricao_produto 
            FROM itens_pedido ip 
            LEFT JOIN produtos pr ON ip.produto_id = pr.id_produto 
            WHERE ip.pedido_id = $1
        `, [id]);
        
        const pedido = pedidoResult.rows[0];
        pedido.itens = itensResult.rows;
        
        res.json(pedido);
    } catch (error) {
        console.error('Erro ao buscar pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar novo pedido
const criarPedido = async (req, res) => {
    try {
        const { usuario_id, itens, observacoes } = req.body;
        
        // Iniciar transação
        await db.query('BEGIN');
        
        try {
            // Criar o pedido
            const pedidoResult = await db.query(
                'INSERT INTO pedidos (usuario_id, observacoes) VALUES ($1, $2) RETURNING *',
                [usuario_id, observacoes]
            );
            
            const pedido = pedidoResult.rows[0];
            let valorTotal = 0;
            
            // Adicionar itens ao pedido
            for (const item of itens) {
                const { produto_id, quantidade } = item;
                
                // Buscar preço atual do produto
                const produtoResult = await db.query('SELECT preco_produto FROM produtos WHERE id_produto = $1', [produto_id]);
                if (produtoResult.rows.length === 0) {
                    throw new Error(`Produto ${produto_id} não encontrado`);
                }
                
                const precoUnitario = produtoResult.rows[0].preco_produto;
                const subtotal = precoUnitario * quantidade;
                valorTotal += subtotal;
                
                // Inserir item do pedido
                await db.query(
                    'INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario, subtotal) VALUES ($1, $2, $3, $4, $5)',
                    [pedido.id_pedido, produto_id, quantidade, precoUnitario, subtotal]
                );
                
                // Atualizar estoque
                await db.query(
                    'UPDATE produtos SET quantidade_estoque = quantidade_estoque - $1 WHERE id_produto = $2',
                    [quantidade, produto_id]
                );
            }
            
            // Atualizar valor total do pedido
            await db.query(
                'UPDATE pedidos SET valor_total = $1 WHERE id_pedido = $2',
                [valorTotal, pedido.id_pedido]
            );
            
            await db.query('COMMIT');
            
            // Buscar pedido completo para retornar
            const pedidoCompleto = await buscarPedidoCompleto(pedido.id_pedido);
            res.status(201).json(pedidoCompleto);
            
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
        
    } catch (error) {
        console.error('Erro ao criar pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar status do pedido
const atualizarStatusPedido = async (req, res) => {
    try {
        const { id } = req.params;
        const { status_pedido } = req.body;
        
        const result = await db.query(
            'UPDATE pedidos SET status_pedido = $1 WHERE id_pedido = $2 RETURNING *',
            [status_pedido, id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao atualizar status do pedido:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Listar pedidos de um usuário
const listarPedidosUsuario = async (req, res) => {
    try {
        const { usuario_id } = req.params;
        const result = await db.query(`
            SELECT p.*, u.nome_usuario 
            FROM pedidos p 
            LEFT JOIN usuarios u ON p.usuario_id = u.id_usuario 
            WHERE p.usuario_id = $1 
            ORDER BY p.data_pedido DESC
        `, [usuario_id]);
        
        res.json(result.rows);
    } catch (error) {
        console.error('Erro ao listar pedidos do usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Função auxiliar para buscar pedido completo
const buscarPedidoCompleto = async (pedidoId) => {
    const pedidoResult = await db.query(`
        SELECT p.*, u.nome_usuario 
        FROM pedidos p 
        LEFT JOIN usuarios u ON p.usuario_id = u.id_usuario 
        WHERE p.id_pedido = $1
    `, [pedidoId]);
    
    const itensResult = await db.query(`
        SELECT ip.*, pr.nome_produto, pr.descricao_produto 
        FROM itens_pedido ip 
        LEFT JOIN produtos pr ON ip.produto_id = pr.id_produto 
        WHERE ip.pedido_id = $1
    `, [pedidoId]);
    
    const pedido = pedidoResult.rows[0];
    pedido.itens = itensResult.rows;
    
    return pedido;
};

module.exports = {
    listarPedidos,
    buscarPedidoPorId,
    criarPedido,
    atualizarStatusPedido,
    listarPedidosUsuario
};

