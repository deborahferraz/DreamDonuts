// server.js – DreamDonuts
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const db = require('./database'); // conexão com PostgreSQL
const authController = require('./controllers/authController');
const session = require('express-session');

const app = express();
const HOST = 'localhost';
const PORT_FIXA = 3001;
const caminhoFrontend = path.join(__dirname, '../frontend');

// --- Middlewares base ---
app.use(express.static(caminhoFrontend));
app.use(cookieParser());
app.use(express.json());

// --- Sessão em memória (pode trocar por redis em produção) ---
app.use(
  session({
    secret: 'donuts-secret-123',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true }
  })
);

// --- CORS com credenciais ---
app.use((req, res, next) => {
  const allowedOrigins = [
    'http://127.0.0.1:5500',
    'http://localhost:5500',
    `http://${HOST}:${PORT_FIXA}`
  ];
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
  }
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  res.header('Access-Control-Allow-Credentials', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// disponibiliza conexão do banco em cada req
app.use((req, _res, next) => {
  req.db = db;
  next();
});

// --- Rotas de autenticação ---
app.post('/register', authController.registro); // compatibilidade
app.use('/auth', require('./routes/authRoutes'));

// --- Rota auxiliar: verificar login ---
app.get('/auth/verificar', (req, res) => {
  if (req.session && req.session.user) {
    return res.json({
      logged: true,
      id_usuario: req.session.user.id_usuario,
      nome: req.session.user.nome_usuario
    });
  }
  return res.json({ logged: false });
});

// --- Rota principal da loja ---
app.get('/', (_req, res) =>
  res.sendFile(path.join(caminhoFrontend, 'index.html'))
);

// --- Rota de produtos (donuts) ---
app.get('/donuts', async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id_produto, nome_produto, descricao_produto, preco_produto, categoria_id FROM produtos'
    );

    if (result.rows.length > 0) {
      return res.json(result.rows);
    }

    return res.json([
      {
        id_produto: 1,
        nome_produto: 'Donut Glazed',
        descricao_produto: 'Donut clássico',
        preco_produto: 4.5,
        categoria_id: 1
      },
      {
        id_produto: 2,
        nome_produto: 'Donut Chocolate',
        descricao_produto: 'Cobertura de chocolate',
        preco_produto: 5.0,
        categoria_id: 1
      },
      {
        id_produto: 3,
        nome_produto: 'Donut Morango',
        descricao_produto: 'Cobertura de morango',
        preco_produto: 5.5,
        categoria_id: 2
      }
    ]);
  } catch (err) {
    console.error('Erro ao carregar donuts:', err);
    res.status(500).json({ error: 'Erro ao carregar produtos' });
  }
});

// --- Health check ---
app.get('/health', async (_req, res) => {
  try {
    const ok = await db.testConnection();
    res.status(ok ? 200 : 500).json({
      status: ok ? 'OK' : 'ERROR',
      message: ok ? 'Servidor e banco OK' : 'Problema na conexão com o banco',
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({ status: 'ERROR', message: err.message });
  }
});

// --- Tratamento de erros ---
app.use((err, _req, res, _next) => {
  console.error('Erro não tratado:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

// --- Rota 404 ---
app.use((req, res) => {
  res
    .status(404)
    .json({ error: 'Rota não encontrada', rota: req.originalUrl });
});

// --- Inicialização ---
(async () => {
  const ok = await db.testConnection();
  if (!ok) {
    console.error('❌ Falha na conexão com PostgreSQL');
    process.exit(1);
  }
  const PORT = process.env.PORT || PORT_FIXA;
  app.listen(PORT, () =>
    console.log(`🚀 Servidor rodando em http://${HOST}:${PORT}`)
  );
})();
