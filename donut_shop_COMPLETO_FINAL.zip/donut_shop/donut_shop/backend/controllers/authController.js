// controllers/authController.js
const db = require('../database');
const bcrypt = require('bcrypt');

// --- Registro ---
exports.registro = async (req, res) => {
  const {
    name, cpf, birthdate, email, password,
    cidade, estado, rua, numero, cep, complemento, bairro
  } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Nome, e-mail e senha são obrigatórios' });
  }

  try {
    // checa email duplicado
    const existing = await db.query(
      'SELECT id_usuario FROM usuarios WHERE email_usuario = $1',
      [email]
    );
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Email já cadastrado' });
    }

    // hash senha
    const hash = await bcrypt.hash(password, 10);

    // insere usuário
    const insertUser = await db.query(
      `INSERT INTO usuarios
         (nome_usuario, email_usuario, senha_usuario, cpf_usuario, nascimento_usuario, data_cadastro, ativo)
       VALUES ($1,$2,$3,$4,$5,NOW(),true)
       RETURNING id_usuario, nome_usuario, email_usuario`,
      [name, email, hash, cpf || null, birthdate || null]
    );

    const user = insertUser.rows[0];

    // insere endereço
    await db.query(
      `INSERT INTO enderecos
         (usuario_id, rua, numero, complemento, bairro, cidade, estado, cep)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        user.id_usuario,
        rua || null,
        numero || null,
        complemento || null,
        bairro || null,
        cidade || null,
        estado || null,
        cep || null
      ]
    );

    // salva sessão
    req.session.user = {
      id_usuario: user.id_usuario,
      nome_usuario: user.nome_usuario,
      email_usuario: user.email_usuario
    };

    res.json(req.session.user);
  } catch (error) {
    console.error('Erro ao registrar usuário:', error);
    res.status(500).json({ error: 'Erro ao registrar usuário' });
  }
};

// --- Login ---
exports.login = async (req, res) => {
  const { email_usuario, senha_usuario } = req.body;
  if (!email_usuario || !senha_usuario) {
    return res.status(400).json({ error: 'E-mail e senha obrigatórios' });
  }

  try {
    const result = await db.query(
      'SELECT id_usuario, nome_usuario, senha_usuario, email_usuario FROM usuarios WHERE email_usuario = $1',
      [email_usuario]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Email ou senha inválidos' });
    }

    const user = result.rows[0];
    const match = await bcrypt.compare(senha_usuario, user.senha_usuario);
    if (!match) return res.status(401).json({ error: 'Email ou senha inválidos' });

    // salva sessão
    req.session.user = {
      id_usuario: user.id_usuario,
      nome_usuario: user.nome_usuario,
      email_usuario: user.email_usuario
    };

    res.json(req.session.user);
  } catch (err) {
    console.error('Erro no login:', err);
    res.status(500).json({ error: 'Erro ao processar login' });
  }
};

// --- Logout ---
exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ ok: true });
  });
};

// --- Verificar sessão ---
exports.verificarLogin = (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ logged: true, ...req.session.user });
  }
  return res.json({ logged: false });
};
