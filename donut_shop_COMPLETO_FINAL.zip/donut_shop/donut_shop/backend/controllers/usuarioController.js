const db = require('../database');
const bcrypt = require('bcrypt');

// Listar todos os usuários
const listarUsuarios = async (req, res) => {
    try {
        const result = await db.query('SELECT id_usuario, nome_usuario, email_usuario, data_cadastro, ativo FROM usuarios ORDER BY nome_usuario');
        res.json(result.rows);
    } catch (error) {
        console.error('Erro ao listar usuários:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Buscar usuário por ID
const buscarUsuarioPorId = async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('SELECT id_usuario, nome_usuario, email_usuario, data_cadastro, ativo FROM usuarios WHERE id_usuario = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao buscar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar novo usuário
const criarUsuario = async (req, res) => {
    try {
        const { nome_usuario, email_usuario, senha_usuario } = req.body;
        
        // Verificar se o email já existe
        const emailExiste = await db.query('SELECT id_usuario FROM usuarios WHERE email_usuario = $1', [email_usuario]);
        if (emailExiste.rows.length > 0) {
            return res.status(400).json({ error: 'Email já cadastrado' });
        }
        
        // Criptografar a senha
        const saltRounds = 10;
        const senhaHash = await bcrypt.hash(senha_usuario, saltRounds);
        
        const result = await db.query(
            'INSERT INTO usuarios (nome_usuario, email_usuario, senha_usuario) VALUES ($1, $2, $3) RETURNING id_usuario, nome_usuario, email_usuario, data_cadastro',
            [nome_usuario, email_usuario, senhaHash]
        );
        
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar usuário
const atualizarUsuario = async (req, res) => {
    try {
        const { id } = req.params;
        const { nome_usuario, email_usuario } = req.body;
        
        // Verificar se o email já existe para outro usuário
        const emailExiste = await db.query('SELECT id_usuario FROM usuarios WHERE email_usuario = $1 AND id_usuario != $2', [email_usuario, id]);
        if (emailExiste.rows.length > 0) {
            return res.status(400).json({ error: 'Email já cadastrado para outro usuário' });
        }
        
        const result = await db.query(
            'UPDATE usuarios SET nome_usuario = $1, email_usuario = $2 WHERE id_usuario = $3 RETURNING id_usuario, nome_usuario, email_usuario, data_cadastro',
            [nome_usuario, email_usuario, id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Erro ao atualizar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar usuário
const deletarUsuario = async (req, res) => {
    try {
        const { id } = req.params;
        
        const result = await db.query('DELETE FROM usuarios WHERE id_usuario = $1 RETURNING id_usuario', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        
        res.json({ message: 'Usuário deletado com sucesso' });
    } catch (error) {
        console.error('Erro ao deletar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = {
    listarUsuarios,
    buscarUsuarioPorId,
    criarUsuario,
    atualizarUsuario,
    deletarUsuario
};

