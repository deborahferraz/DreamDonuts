const API_URL = "/api/usuarios";

document.addEventListener("DOMContentLoaded", () => {
  carregarUsuarios();
  document.getElementById("btnBuscar").addEventListener("click", buscarUsuario);
  document.getElementById("btnIncluir").addEventListener("click", prepararIncluir);
  document.getElementById("btnAlterar").addEventListener("click", prepararAlterar);
  document.getElementById("btnExcluir").addEventListener("click", excluirUsuario);
  document.getElementById("btnSalvar").addEventListener("click", salvarUsuario);
  document.getElementById("btnCancelar").addEventListener("click", resetarFormulario);
  
  // Adicionar formatação automática do CPF
  const cpfInput = document.getElementById("cpf_usuario");
  if (cpfInput) {
    cpfInput.addEventListener("input", formatarCPF);
  }
});

async function carregarUsuarios() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error("Falha ao carregar");
    const usuarios = await response.json();
    const tbody = document.getElementById("usuariosTableBody");
    tbody.innerHTML = "";
    usuarios.forEach(u => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${u.id_usuario}</td>
        <td>${u.nome_usuario}</td>
        <td>${u.email_usuario}</td>
        <td>${u.cpf_usuario || ""}</td>
        <td>${u.ativo ? "Sim" : "Não"}</td>
        <td>${u.papel}</td>
        <td>${new Date(u.data_cadastro).toLocaleDateString()}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    mostrarMensagem("Erro ao carregar usuários: " + err.message, "error");
  }
}

async function buscarUsuario() {
  const id = document.getElementById("searchId").value;
  if (!id) return mostrarMensagem("Informe um ID para buscar", "error");
  try {
    const r = await fetch(`${API_URL}/${id}`);
    if (!r.ok) throw new Error("Usuário não encontrado");
    const u = await r.json();
    preencherFormulario(u);
    document.getElementById("btnAlterar").style.display = "inline-block";
    document.getElementById("btnExcluir").style.display = "inline-block";
  } catch (e) { mostrarMensagem(e.message, "error"); }
}

function preencherFormulario(u) {
  document.getElementById("nome_usuario").value = u.nome_usuario;
  document.getElementById("email_usuario").value = u.email_usuario;
  document.getElementById("senha_usuario").value = "";
  document.getElementById("cpf_usuario").value = u.cpf_usuario || "";
  document.getElementById("nascimento_usuario").value =
    u.nascimento_usuario ? new Date(u.nascimento_usuario).toISOString().split("T")[0] : "";
  document.getElementById("ativo").value = u.ativo ? "true" : "false";
  document.getElementById("papel").value = u.papel;
}

function prepararIncluir() { resetarFormulario(); document.getElementById("btnSalvar").style.display = "inline-block"; }
function prepararAlterar() { document.getElementById("btnSalvar").style.display = "inline-block"; }

async function salvarUsuario() {
  const id = document.getElementById("searchId").value;
  const cpfValue = document.getElementById("cpf_usuario").value;
  const usuario = {
    nome_usuario: document.getElementById("nome_usuario").value,
    email_usuario: document.getElementById("email_usuario").value,
    senha_usuario: document.getElementById("senha_usuario").value,
    cpf_usuario: limparCPF(cpfValue), // Remove formatação antes de enviar
    nascimento_usuario: document.getElementById("nascimento_usuario").value,
    ativo: document.getElementById("ativo").value === "true",
    papel: document.getElementById("papel").value
  };
  try {
    const opts = {
      method: id ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(usuario)
    };
    const r = await fetch(id ? `${API_URL}/${id}` : API_URL, opts);
    if (!r.ok) throw new Error("Erro ao salvar");
    mostrarMensagem("Usuário salvo com sucesso!", "success");
    resetarFormulario();
    carregarUsuarios();
  } catch (e) { mostrarMensagem(e.message, "error"); }
}

async function excluirUsuario() {
  const id = document.getElementById("searchId").value;
  if (!id) return mostrarMensagem("Informe um ID", "error");
  if (!confirm("Deseja realmente excluir?")) return;
  try {
    const r = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!r.ok) throw new Error("Erro ao excluir");
    mostrarMensagem("Usuário excluído!", "success");
    resetarFormulario();
    carregarUsuarios();
  } catch (e) { mostrarMensagem(e.message, "error"); }
}

function resetarFormulario() {
  document.getElementById("usuarioForm").reset();
  document.getElementById("searchId").value = "";
  ["btnSalvar","btnAlterar","btnExcluir"].forEach(id => document.getElementById(id).style.display="none");
}

function mostrarMensagem(msg,tipo){
  const c=document.getElementById("messageContainer");
  c.textContent=msg; c.className=`message-container ${tipo}`;
  setTimeout(()=>{c.textContent=""; c.className="message-container";},3000);
}

// Função para formatar CPF automaticamente
function formatarCPF(e) {
  let value = e.target.value.replace(/\D/g, ''); // Remove tudo que não é dígito
  
  // Limita a 11 dígitos
  if (value.length > 11) {
    value = value.substring(0, 11);
  }
  
  // Aplica a formatação
  if (value.length <= 11) {
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  }
  
  e.target.value = value;
}

// Função para remover formatação do CPF antes de enviar
function limparCPF(cpf) {
  return cpf.replace(/\D/g, '');
}

