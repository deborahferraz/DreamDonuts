// -------- CARREGAR PRODUTOS --------
async function carregarProdutos() {
  try {
    const response = await fetch("http://localhost:3001/produto");
    if (!response.ok) throw new Error("Erro ao buscar produtos");

    const produtos = await response.json();
    const tabela = document.getElementById("lista-produtos");
    tabela.innerHTML = "";

    produtos.forEach(p => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${p.id_produto}</td>
        <td>${p.nome_produto}</td>
        <td>${p.descricao_produto || ""}</td>
        <td>R$ ${(parseFloat(p.preco_produto) || 0).toFixed(2)}</td>
        <td>${p.quantidade_estoque}</td>
        <td><img src="${p.imagem_produto || ""}" alt="img" width="50"></td>
        <td>${p.categoria_id}</td>
        <td>${p.ativo ? "Sim" : "Não"}</td>
        <td>${new Date(p.data_criacao).toLocaleDateString()}</td>
        <td>
          <button class="btn-secondary btn-small" onclick="editarProduto(${p.id_produto})">Editar</button>
          <button class="btn-danger btn-small" onclick="excluirProduto(${p.id_produto})">Excluir</button>
        </td>
      `;
      tabela.appendChild(tr);
    });
  } catch (erro) {
    console.error("Erro ao carregar produtos:", erro);
  }
}

// -------- CADASTRAR / EDITAR --------
const form = document.getElementById("form-produto");
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("id_produto").value;
  const formData = new FormData();
  const fileInput = document.getElementById("imagem_produto");

  formData.append("nome_produto", document.getElementById("nome_produto").value);
  formData.append("descricao_produto", document.getElementById("descricao_produto").value);
  formData.append("preco_produto", document.getElementById("preco_produto").value.replace(',', '.'));
  formData.append("quantidade_estoque", document.getElementById("quantidade_estoque").value);
  formData.append("categoria_id", document.getElementById("categoria_id").value);
  
  const ativoValue = document.getElementById('ativo').value === 'true';
formData.append('ativo', ativoValue);

  if (fileInput.files[0]) {
    formData.append("imagem_produto", fileInput.files[0]);
  }

  try {
    let response;
    if (id) {
      response = await fetch(`http://localhost:3001/produto/${id}`, {
        method: "PUT",
        body: formData
      });
    } else {
      response = await fetch("http://localhost:3001/produto", {
        method: "POST",
        body: formData
      });
    }

    if (!response.ok) throw new Error("Erro ao salvar produto");

    form.reset();
    carregarProdutos();
  } catch (erro) {
    console.error("Erro ao salvar produto:", erro);
  }
});

// -------- EDITAR PRODUTO --------
async function editarProduto(id) {
  try {
    const response = await fetch(`http://localhost:3001/produto/${id}`);
    if (!response.ok) throw new Error("Erro ao buscar produto");

    const p = await response.json();

    document.getElementById("id_produto").value = p.id_produto;
    document.getElementById("nome_produto").value = p.nome_produto;
    document.getElementById("descricao_produto").value = p.descricao_produto || "";
    document.getElementById("preco_produto").value = p.preco_produto;
    document.getElementById("quantidade_estoque").value = p.quantidade_estoque;
    document.getElementById("categoria_id").value = p.categoria_id;
    document.getElementById("ativo").value = p.ativo ? "true" : "false";
  } catch (erro) {
    console.error("Erro ao editar produto:", erro);
  }
}

// -------- EXCLUIR PRODUTO --------
async function excluirProduto(id) {
  if (!confirm("Tem certeza que deseja excluir este produto?")) return;

  try {
    const response = await fetch(`http://localhost:3001/produto/${id}`, {
      method: "DELETE"
    });
    if (!response.ok) throw new Error("Erro ao excluir produto");

    carregarProdutos();
  } catch (erro) {
    console.error("Erro ao excluir produto:", erro);
  }
}

// -------- INICIAR --------
document.addEventListener("DOMContentLoaded", carregarProdutos);
