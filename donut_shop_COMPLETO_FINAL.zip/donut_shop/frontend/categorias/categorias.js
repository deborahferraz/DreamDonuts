const API_URL = "/api/categorias";

document.addEventListener("DOMContentLoaded", () => {
  carregarCategorias();
  document.getElementById("btnBuscar").addEventListener("click", buscarCategoria);
  document.getElementById("btnIncluir").addEventListener("click", prepararIncluir);
  document.getElementById("btnAlterar").addEventListener("click", prepararAlterar);
  document.getElementById("btnExcluir").addEventListener("click", excluirCategoria);
  document.getElementById("btnSalvar").addEventListener("click", salvarCategoria);
  document.getElementById("btnCancelar").addEventListener("click", resetarFormulario);
});

async function carregarCategorias() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error("Falha ao carregar categorias");
    const categorias = await response.json();
    const tbody = document.getElementById("categoriasTableBody");
    tbody.innerHTML = "";
    categorias.forEach(c => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${c.id_categoria}</td>
        <td>${c.nome_categoria}</td>
        <td>${c.descricao_categoria || ""}</td>
        <td>
          <button class="btn-id btn-small" onclick="buscarCategoriaPorId(${c.id_categoria})">
            Editar
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    mostrarMensagem("Erro ao carregar categorias: " + err.message, "error");
  }
}

async function buscarCategoria() {
  const id = document.getElementById("searchId").value;
  if (!id) return mostrarMensagem("Informe um ID para buscar", "error");
  await buscarCategoriaPorId(id);
}

async function buscarCategoriaPorId(id) {
  try {
    const r = await fetch(`${API_URL}/${id}`);
    if (!r.ok) throw new Error("Categoria não encontrada");
    const c = await r.json();
    preencherFormulario(c);
    document.getElementById("searchId").value = id;
    document.getElementById("btnAlterar").style.display = "inline-block";
    document.getElementById("btnExcluir").style.display = "inline-block";
    document.getElementById("btnCancelar").style.display = "inline-block";
  } catch (e) { 
    mostrarMensagem(e.message, "error"); 
  }
}

function preencherFormulario(c) {
  document.getElementById("nome_categoria").value = c.nome_categoria;
  document.getElementById("descricao_categoria").value = c.descricao_categoria || "";
}

function prepararIncluir() { 
  resetarFormulario(); 
  document.getElementById("btnSalvar").style.display = "inline-block";
  document.getElementById("btnCancelar").style.display = "inline-block";
}

function prepararAlterar() { 
  document.getElementById("btnSalvar").style.display = "inline-block";
  document.getElementById("btnAlterar").style.display = "none";
  document.getElementById("btnExcluir").style.display = "none";
}

async function salvarCategoria() {
  const id = document.getElementById("searchId").value;
  const categoria = {
    nome_categoria: document.getElementById("nome_categoria").value,
    descricao_categoria: document.getElementById("descricao_categoria").value
  };
  
  if (!categoria.nome_categoria.trim()) {
    mostrarMensagem("Nome da categoria é obrigatório", "error");
    return;
  }
  
  try {
    const opts = {
      method: id ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(categoria)
    };
    const r = await fetch(id ? `${API_URL}/${id}` : API_URL, opts);
    if (!r.ok) throw new Error("Erro ao salvar categoria");
    mostrarMensagem("Categoria salva com sucesso!", "success");
    resetarFormulario();
    carregarCategorias();
  } catch (e) { 
    mostrarMensagem(e.message, "error"); 
  }
}

async function excluirCategoria() {
  const id = document.getElementById("searchId").value;
  if (!id) return mostrarMensagem("Informe um ID", "error");
  if (!confirm("Deseja realmente excluir esta categoria?")) return;
  try {
    const r = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!r.ok) throw new Error("Erro ao excluir categoria");
    mostrarMensagem("Categoria excluída!", "success");
    resetarFormulario();
    carregarCategorias();
  } catch (e) { 
    mostrarMensagem(e.message, "error"); 
  }
}

function resetarFormulario() {
  document.getElementById("categoriaForm").reset();
  document.getElementById("searchId").value = "";
  ["btnSalvar","btnAlterar","btnExcluir","btnCancelar"].forEach(id => 
    document.getElementById(id).style.display="none"
  );
}

function mostrarMensagem(msg, tipo) {
  const container = document.getElementById("messageContainer");
  const messageDiv = document.createElement("div");
  messageDiv.className = `message ${tipo}`;
  messageDiv.textContent = msg;
  container.appendChild(messageDiv);
  
  setTimeout(() => {
    container.removeChild(messageDiv);
  }, 3000);
}

