const express = require('express');
const router = express.Router();
const menuController = require('../controllers/menuController');

// Rota para obter dados do menu
router.get('/', menuController.getMenuData);

module.exports = router;

