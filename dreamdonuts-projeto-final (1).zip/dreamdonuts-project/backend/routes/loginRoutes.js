const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController');

// Rota para fazer login
router.post('/', loginController.login);

// Rota para fazer logout
router.post('/logout', loginController.logout);

// Rota para verificar se o usuário está logado
router.get('/verificar', loginController.verificarLogin);

module.exports = router;

