const express = require('express');
const router = express.Router();
const funcionarioController = require('../controllers/funcionarioController');

// Listar todos os funcionários
router.get('/', funcionarioController.listarFuncionarios);

// Obter funcionário por CPF
router.get('/:cpf', funcionarioController.obterFuncionario);

// Criar novo funcionário
router.post('/', funcionarioController.criarFuncionario);

// Atualizar funcionário
router.put('/:cpf', funcionarioController.atualizarFuncionario);

// Deletar funcionário
router.delete('/:cpf', funcionarioController.deletarFuncionario);

// Listar cargos para dropdown
router.get('/dados/cargos', funcionarioController.listarCargos);

module.exports = router;

