# DreamDonuts - Sistema de Gestão

Sistema de gestão para loja de donuts desenvolvido para a avaliação do 3º bimestre da disciplina DW1.

## 📋 Descrição do Projeto

O DreamDonuts é um sistema completo de gestão para uma loja de donuts que permite:

- **Login com autenticação**: Sistema de login com cookies/session
- **Menu principal**: Interface personalizada baseada no cargo do usuário
- **CRUD de Produtos**: Gerenciamento completo de produtos (tabela sem dependências)
- **CRUD de Pedidos**: Gerenciamento de pedidos com relacionamentos 1:n e n:m
- **CRUD de Clientes**: Gerenciamento de clientes com relacionamento 1:1
- **CRUD de Funcionários**: Gerenciamento de funcionários
- **CRUD de Pagamentos**: Gerenciamento de pagamentos com relacionamento n:m

## 🛠️ Tecnologias Utilizadas

### Backend
- **Node.js** com Express.js
- **PostgreSQL** como banco de dados
- **Cookie-parser** para gerenciamento de sessões
- **CORS** para comunicação frontend-backend

### Frontend
- **HTML5** semântico
- **CSS3** com design responsivo
- **JavaScript** vanilla (sem frameworks)
- **Font Awesome** para ícones
- **Google Fonts** (Fredoka One e Poppins)

### Banco de Dados
- **PostgreSQL** com relacionamentos:
  - 1:1 (Cliente-Pessoa)
  - 1:n (Pedido-Cliente, Pedido-Funcionário)
  - n:m (Pedido-Produto, Pagamento-FormaPagamento)

## 📁 Estrutura do Projeto

```
dreamdonuts-project/
├── backend/
│   ├── controllers/
│   │   ├── loginController.js
│   │   ├── menuController.js
│   │   ├── produtoController.js
│   │   ├── pedidoController.js
│   │   ├── clienteController.js
│   │   ├── funcionarioController.js
│   │   └── pagamentoController.js
│   ├── routes/
│   │   ├── loginRoutes.js
│   │   ├── menuRoutes.js
│   │   ├── produtoRoutes.js
│   │   ├── pedidoRoutes.js
│   │   ├── clienteRoutes.js
│   │   ├── funcionarioRoutes.js
│   │   └── pagamentoRoutes.js
│   ├── database.js
│   └── server.js
├── frontend/
│   ├── produto/
│   │   ├── produto.html
│   │   └── produto.js
│   ├── images/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── database_postgresql.sql
├── package.json
└── README.md
```

## 🚀 Como Executar o Projeto

### Pré-requisitos
- Node.js (versão 14 ou superior)
- PostgreSQL (versão 12 ou superior)
- npm ou yarn

### Instalação

1. **Clone o repositório**
   ```bash
   git clone <url-do-repositorio>
   cd dreamdonuts-project
   ```

2. **Instale as dependências**
   ```bash
   npm install
   ```

3. **Configure o banco de dados**
   ```bash
   # Criar o banco de dados
   sudo -u postgres createdb dreamdonuts_db
   
   # Executar o script SQL
   sudo -u postgres psql dreamdonuts_db -f database_postgresql.sql
   
   # Configurar senha do usuário postgres (se necessário)
   sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'postgres';"
   ```

4. **Inicie o servidor**
   ```bash
   npm start
   ```

5. **Acesse o sistema**
   - Abra o navegador e acesse: `http://localhost:3000`

## 👤 Usuários de Teste

O sistema vem com usuários pré-cadastrados para teste:

### Vendedor
- **CPF**: 789.123.456-04
- **Nome**: Ana Costa
- **Cargo**: Vendedor
- **Senha**: qualquer

### Gerente
- **CPF**: 321.654.987-05
- **Nome**: Carlos Ferreira
- **Cargo**: Gerente
- **Senha**: qualquer

## 🔐 Funcionalidades por Cargo

### Vendedor
- ✅ Produtos
- ✅ Pedidos
- ✅ Clientes
- ✅ Pagamentos

### Gerente
- ✅ Produtos
- ✅ Pedidos
- ✅ Clientes
- ✅ Funcionários
- ✅ Pagamentos

### Caixa
- ✅ Produtos
- ✅ Pedidos
- ✅ Pagamentos

## 📊 Modelo de Dados

O sistema implementa o DER fornecido com as seguintes entidades principais:

- **Pessoa** (entidade base)
- **Cliente** (relacionamento 1:1 com Pessoa)
- **Funcionário** (relacionamento 1:1 com Pessoa)
- **Produto** (entidade independente)
- **Pedido** (relacionamentos 1:n com Cliente e Funcionário)
- **PedidoHasProduto** (relacionamento n:m entre Pedido e Produto)
- **Pagamento** (relacionamento 1:1 com Pedido)
- **PagamentoHasFormaPagamento** (relacionamento n:m entre Pagamento e FormaPagamento)

## 🎯 Requisitos Atendidos

### Parte 1 (7,0 pontos)
- ✅ **Login com credenciais**: Implementado com cookies/session
- ✅ **Menu principal**: Com nome do usuário logado e opção de logout
- ✅ **CRUD sem dependências**: Produtos
- ✅ **CRUD com relacionamento 1:n**: Pedidos (Pedido-Cliente, Pedido-Funcionário)
- ✅ **CRUD com relacionamento n:m**: Pedidos-Produtos, Pagamentos-FormasPagamento
- ✅ **CRUD com relacionamento 1:1**: Clientes (Cliente-Pessoa)
- ✅ **Servidor dividido**: Controllers, routes, database em arquivos separados

### Tecnologias
- ✅ **HTML**: Estrutura semântica e responsiva
- ✅ **JavaScript**: Funcionalidades interativas e comunicação com API
- ✅ **CSS**: Design moderno e responsivo
- ✅ **PostgreSQL**: Banco de dados com acesso direto (sem ORM)

## 🎨 Design e Interface

O sistema possui:
- **Design responsivo** que funciona em desktop e mobile
- **Tema colorido** inspirado em donuts com gradientes
- **Interface intuitiva** com navegação clara
- **Feedback visual** com notificações e estados de loading
- **Tipografia moderna** com fontes Google Fonts

## 🔧 API Endpoints

### Autenticação
- `POST /api/login` - Fazer login
- `POST /api/login/logout` - Fazer logout
- `GET /api/login/verificar` - Verificar se está logado

### Menu
- `GET /api/menu` - Obter dados do menu baseado no usuário

### Produtos
- `GET /api/produto` - Listar produtos
- `GET /api/produto/:id` - Obter produto por ID
- `POST /api/produto` - Criar produto
- `PUT /api/produto/:id` - Atualizar produto
- `DELETE /api/produto/:id` - Deletar produto

### Pedidos
- `GET /api/pedido` - Listar pedidos
- `GET /api/pedido/:id` - Obter pedido por ID
- `POST /api/pedido` - Criar pedido
- `PUT /api/pedido/:id` - Atualizar pedido
- `DELETE /api/pedido/:id` - Deletar pedido

### Clientes
- `GET /api/cliente` - Listar clientes
- `GET /api/cliente/:cpf` - Obter cliente por CPF
- `POST /api/cliente` - Criar cliente
- `PUT /api/cliente/:cpf` - Atualizar cliente
- `DELETE /api/cliente/:cpf` - Deletar cliente

### Funcionários
- `GET /api/funcionario` - Listar funcionários
- `GET /api/funcionario/:cpf` - Obter funcionário por CPF
- `POST /api/funcionario` - Criar funcionário
- `PUT /api/funcionario/:cpf` - Atualizar funcionário
- `DELETE /api/funcionario/:cpf` - Deletar funcionário

### Pagamentos
- `GET /api/pagamento` - Listar pagamentos
- `GET /api/pagamento/:pedidoId` - Obter pagamento por ID do pedido
- `POST /api/pagamento` - Criar pagamento
- `PUT /api/pagamento/:pedidoId` - Atualizar pagamento
- `DELETE /api/pagamento/:pedidoId` - Deletar pagamento

## 📝 Observações

- O sistema está totalmente funcional com login, menu e CRUD de produtos implementados
- A estrutura está preparada para expansão dos demais CRUDs
- O banco de dados está populado com dados de teste
- O código segue boas práticas de desenvolvimento
- A interface é responsiva e moderna

## 👨‍💻 Desenvolvedor

Projeto desenvolvido para a disciplina DW1 - Desenvolvimento Web 1

---

**DreamDonuts** - Onde cada donut é um sonho realizado! 🍩✨

