// Elementos DOM
const addProductBtn = document.getElementById('addProductBtn');
const productForm = document.getElementById('productForm');
const productFormElement = document.getElementById('productFormElement');
const formTitle = document.getElementById('formTitle');
const cancelBtn = document.getElementById('cancelBtn');
const loadingProducts = document.getElementById('loadingProducts');
const productsTable = document.getElementById('productsTable');
const logoutBtn = document.getElementById('logoutBtn');

// Estado
let editingProductId = null;
let products = [];

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializePage();
});

// Inicializar página
async function initializePage() {
    try {
        // Verificar se o usuário está logado
        const response = await fetch('/api/login/verificar', {
            credentials: 'include'
        });

        if (!response.ok) {
            window.location.href = '../index.html';
            return;
        }

        const data = await response.json();
        if (data.success) {
            document.getElementById('userName').textContent = data.user.nome;
            document.getElementById('userRole').textContent = data.user.cargo;
        }

        // Carregar produtos
        await loadProducts();

        // Event listeners
        addProductBtn.addEventListener('click', showAddForm);
        cancelBtn.addEventListener('click', hideForm);
        productFormElement.addEventListener('submit', handleSubmit);
        logoutBtn.addEventListener('click', handleLogout);

    } catch (error) {
        console.error('Erro ao inicializar página:', error);
        showNotification('Erro ao carregar página', 'error');
    }
}

// Mostrar formulário de adicionar
function showAddForm() {
    editingProductId = null;
    formTitle.textContent = 'Novo Produto';
    productFormElement.reset();
    document.getElementById('productId').value = '';
    productForm.style.display = 'block';
    productForm.scrollIntoView({ behavior: 'smooth' });
}

// Mostrar formulário de editar
function showEditForm(product) {
    editingProductId = product.idproduto;
    formTitle.textContent = 'Editar Produto';
    
    document.getElementById('productId').value = product.idproduto;
    document.getElementById('nomeProduto').value = product.nomeproduto;
    document.getElementById('precoUnitario').value = product.precounitario;
    document.getElementById('quantidadeEmEstoque').value = product.quantidadeemestoque || 0;
    
    productForm.style.display = 'block';
    productForm.scrollIntoView({ behavior: 'smooth' });
}

// Esconder formulário
function hideForm() {
    productForm.style.display = 'none';
    editingProductId = null;
    productFormElement.reset();
}

// Carregar produtos
async function loadProducts() {
    try {
        loadingProducts.style.display = 'block';
        
        const data = await apiRequest('/produto');
        
        if (data.success) {
            products = data.produtos;
            renderProductsTable();
        } else {
            showNotification('Erro ao carregar produtos', 'error');
        }
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        showNotification('Erro ao carregar produtos', 'error');
    } finally {
        loadingProducts.style.display = 'none';
    }
}

// Renderizar tabela de produtos
function renderProductsTable() {
    if (products.length === 0) {
        productsTable.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-box-open"></i>
                <h3>Nenhum produto cadastrado</h3>
                <p>Clique em "Novo Produto" para adicionar o primeiro produto.</p>
            </div>
        `;
        return;
    }

    const tableHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Estoque</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                ${products.map(product => `
                    <tr>
                        <td>${product.idproduto}</td>
                        <td>${product.nomeproduto}</td>
                        <td>${formatCurrency(product.precounitario)}</td>
                        <td>${product.quantidadeemestoque || 0}</td>
                        <td class="actions">
                            <button class="btn btn-info" onclick="showEditForm(${JSON.stringify(product).replace(/"/g, '&quot;')})">
                                <i class="fas fa-edit"></i>
                                Editar
                            </button>
                            <button class="btn btn-danger" onclick="deleteProduct(${product.idproduto})">
                                <i class="fas fa-trash"></i>
                                Excluir
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;

    productsTable.innerHTML = tableHTML;
}

// Manipular envio do formulário
async function handleSubmit(event) {
    event.preventDefault();

    const formData = new FormData(productFormElement);
    const productData = {
        nomeProduto: formData.get('nomeProduto'),
        precoUnitario: parseFloat(formData.get('precoUnitario')),
        quantidadeEmEstoque: parseInt(formData.get('quantidadeEmEstoque')) || 0
    };

    try {
        let response;
        
        if (editingProductId) {
            // Atualizar produto existente
            response = await apiRequest(`/produto/${editingProductId}`, {
                method: 'PUT',
                body: JSON.stringify(productData)
            });
        } else {
            // Criar novo produto
            response = await apiRequest('/produto', {
                method: 'POST',
                body: JSON.stringify(productData)
            });
        }

        if (response.success) {
            showNotification(response.message, 'success');
            hideForm();
            await loadProducts();
        } else {
            showNotification(response.error || 'Erro ao salvar produto', 'error');
        }
    } catch (error) {
        console.error('Erro ao salvar produto:', error);
        showNotification('Erro ao salvar produto', 'error');
    }
}

// Deletar produto
async function deleteProduct(productId) {
    if (!confirm('Tem certeza que deseja excluir este produto?')) {
        return;
    }

    try {
        const response = await apiRequest(`/produto/${productId}`, {
            method: 'DELETE'
        });

        if (response.success) {
            showNotification(response.message, 'success');
            await loadProducts();
        } else {
            showNotification(response.error || 'Erro ao excluir produto', 'error');
        }
    } catch (error) {
        console.error('Erro ao excluir produto:', error);
        showNotification('Erro ao excluir produto', 'error');
    }
}

// Manipular logout
async function handleLogout() {
    try {
        const response = await fetch('/api/login/logout', {
            method: 'POST',
            credentials: 'include'
        });

        if (response.ok) {
            window.location.href = '../index.html';
        }
    } catch (error) {
        console.error('Erro no logout:', error);
    }
}

